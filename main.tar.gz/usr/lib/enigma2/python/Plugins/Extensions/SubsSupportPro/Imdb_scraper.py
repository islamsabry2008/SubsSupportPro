# -*- coding: utf-8 -*-
import json
import logging
import re
import six

try:
    import requests
    from requests.packages.urllib3.exceptions import InsecureRequestWarning  # type: ignore
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except Exception:
    pass

logger = logging.getLogger("SubsSupportPro.IMDb")

IMDB_GRAPHQL_URL = "https://caching.graphql.imdb.com/"
IMDB_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"


def _to_text(value):
    if value is None:
        return ""
    if six.PY2 and isinstance(value, str):
        return value.decode("utf-8", "ignore")
    if six.PY3 and isinstance(value, bytes):
        return value.decode("utf-8", "ignore")
    return six.text_type(value)


def _clean_query(text):
    if not text:
        return ""
    cleaned = _to_text(text)
    # Remove bracketed/parenthetical text (e.g. "(2017)", "[1080p]")
    cleaned = re.sub(r'[\(\[].*?[\)\]]', '', cleaned)
    # Replace dots and underscores with spaces
    cleaned = re.sub(r'[\._]+', ' ', cleaned)
    return ' '.join(cleaned.split()).strip()


def _get_imdb_headers():
    return {
        "content-type": "application/json",
        "referer": "https://www.imdb.com/",
        "User-Agent": IMDB_USER_AGENT
    }


def _make_imdb_thumbnail_url(url, target_height=140):
    if not url:
        return None
    # IMDb / Amazon CDN format: replace '._V1_.jpg' with '._V1_QL75_UY<height>_.jpg'
    if "._V1_." in url or "._V1_" in url:
        return re.sub(r'\._V1_.*?\.', '._V1_QL75_UY%d_.' % target_height, url)
    return url


def scrape_imdb_movies(search_term, limit=25):
    """
    Directly searches IMDb via its GraphQL caching endpoint.
    Returns a normalized list of movie and TV show dictionaries with original English titles,
    international AKAs, ratings, votes, genres, runtime, plots, and optimized poster URLs.
    """
    clean_term = _clean_query(search_term)
    if not clean_term:
        return []

    logger.info("IMDb GraphQL search starting | term=%s", clean_term)

    query = """query Search {
  mainSearch(
    first: %d
    options: {
      searchTerm: %s
      type: TITLE
      includeAdult: true
      isExactMatch: false
      titleSearchOptions: {
        type: [MOVIE, TV]
      }
    }
  ) {
    edges {
      node {
        entity {
          ... on Title {
            id
            titleText { text }
            originalTitleText { text }
            titleType { text }
            releaseYear { year endYear }
            ratingsSummary { aggregateRating voteCount }
            primaryImage { url width height }
            plot { plotText { plainText } }
            genres { genres { text } }
            runtime { displayableProperty { value { plainText } } }
          }
        }
      }
    }
  }
}""" % (max(limit, 10), json.dumps(clean_term))

    headers = _get_imdb_headers()
    payload = json.dumps({"query": query})
    if six.PY3 and isinstance(payload, str):
        payload = payload.encode("utf-8")

    try:
        response = requests.post(
            IMDB_GRAPHQL_URL,
            data=payload,
            headers=headers,
            verify=False,
            timeout=8
        )
        if response.status_code != 200:
            logger.warning("IMDb GraphQL query returned HTTP %s",
                           response.status_code)
            return []

        data = response.json()
        edges = data.get("data", {}).get("mainSearch", {}).get("edges", [])
        results = []

        for edge in edges:
            entity = edge.get("node", {}).get("entity", {})
            if not entity:
                continue

            imdb_id = entity.get("id") or ""
            disp_title = (entity.get("titleText", {}) or {}).get("text") or ""
            orig_title = (entity.get("originalTitleText", {})
                          or {}).get("text") or disp_title
            title_type_obj = entity.get("titleType") or {}
            title_type_text = (title_type_obj.get("text") or "").lower(
            ) if isinstance(title_type_obj, dict) else ""
            is_tv = "tv" in title_type_text or "series" in title_type_text

            rel_year_obj = entity.get("releaseYear") or {}
            year = ""
            if isinstance(rel_year_obj, dict):
                y = rel_year_obj.get("year")
                ey = rel_year_obj.get("endYear")
                if y:
                    year = str(y)
                    if ey and is_tv and str(ey) != str(y):
                        year = "%s-%s" % (y, ey)

            ratings_obj = entity.get("ratingsSummary") or {}
            rating = None
            vote_count = None
            if isinstance(ratings_obj, dict):
                rating = ratings_obj.get("aggregateRating")
                vote_count = ratings_obj.get("voteCount")

            img_obj = entity.get("primaryImage") or {}
            poster_url = img_obj.get("url") if isinstance(
                img_obj, dict) else None
            poster_thumb = _make_imdb_thumbnail_url(
                poster_url, 140) if poster_url else None

            plot_obj = entity.get("plot") or {}
            plot_text = ""
            if isinstance(plot_obj, dict):
                pt = plot_obj.get("plotText") or {}
                if isinstance(pt, dict):
                    plot_text = pt.get("plainText") or ""

            genres_obj = entity.get("genres") or {}
            genre_list = []
            if isinstance(genres_obj, dict):
                for g in genres_obj.get("genres", []):
                    if isinstance(g, dict) and g.get("text"):
                        genre_list.append(g.get("text"))

            runtime_obj = entity.get("runtime") or {}
            runtime_str = ""
            if isinstance(runtime_obj, dict):
                dp = runtime_obj.get("displayableProperty") or {}
                if isinstance(dp, dict):
                    val = dp.get("value") or {}
                    if isinstance(val, dict):
                        runtime_str = val.get("plainText") or ""

            media_type = "tv" if is_tv else "movie"

            results.append({
                "id": imdb_id,
                "imdb_id": imdb_id,
                "tmdb_id": imdb_id,
                "title": orig_title or disp_title,
                "original_title": orig_title or disp_title,
                "display_title": disp_title or orig_title,
                "year": year,
                "release_date": year[:4] if len(year) >= 4 else year,
                "media_type": media_type,
                "vote_average": rating or 0.0,
                "vote_count": vote_count or 0,
                "rating": rating or 0.0,
                "runtime": runtime_str,
                "genres": genre_list,
                "genres_str": ", ".join(genre_list),
                "overview": plot_text,
                "poster_url": poster_thumb or poster_url,
                "poster_big_url": poster_url,
                "_match_method": "IMDb",
                "_source_kind": "imdb",
                "_source_query": clean_term
            })

        logger.info(
            "IMDb GraphQL search completed | term=%s | found=%d", clean_term, len(results))
        return results

    except Exception:
        logger.exception(
            "Error during IMDb GraphQL search | term=%s", clean_term)
        return []


def scrape_imdb_details(imdb_id):
    """
    Fetches full storyline, cast, crew, ratings, and runtime for a specific IMDb ID.
    Returns a details dictionary compatible with MovieDetailsProScreen.
    """
    if not imdb_id or not str(imdb_id).startswith("tt"):
        return None

    logger.info("IMDb GraphQL details starting | id=%s", imdb_id)

    query = """query TitleStoryline {
  title(id: %s) {
    id
    titleText { text }
    originalTitleText { text }
    titleType { text }
    releaseYear { year endYear }
    ratingsSummary { aggregateRating voteCount }
    primaryImage { url width height }
    plot { plotText { plainText } }
    genres { genres { text } }
    runtime { displayableProperty { value { plainText } } }
    castV2: principalCreditsV2(filter: { mode: "TOP_CAST" }, useEntitlement: false) {
      credits(limit: 12) {
        name { id nameText { text } }
      }
    }
    crewV2: principalCreditsV2(filter: { mode: "DEFAULT", includeAppearances: false }, useEntitlement: false) {
      credits(limit: 5) {
        name { id nameText { text } }
      }
    }
  }
}""" % json.dumps(str(imdb_id))

    headers = _get_imdb_headers()
    payload = json.dumps({"query": query})
    if six.PY3 and isinstance(payload, str):
        payload = payload.encode("utf-8")

    try:
        response = requests.post(
            IMDB_GRAPHQL_URL,
            data=payload,
            headers=headers,
            verify=False,
            timeout=8
        )
        if response.status_code != 200:
            return None

        data = response.json()
        title_node = data.get("data", {}).get("title", {})
        if not title_node:
            return None

        disp_title = (title_node.get("titleText", {}) or {}).get("text") or ""
        orig_title = (title_node.get("originalTitleText", {})
                      or {}).get("text") or disp_title

        rel_year = ""
        y_obj = title_node.get("releaseYear") or {}
        if isinstance(y_obj, dict):
            rel_year = str(y_obj.get("year") or "")

        ratings_obj = title_node.get("ratingsSummary") or {}
        rating = ratings_obj.get("aggregateRating") if isinstance(
            ratings_obj, dict) else None
        vote_count = ratings_obj.get("voteCount") if isinstance(
            ratings_obj, dict) else None

        img_obj = title_node.get("primaryImage") or {}
        poster_url = img_obj.get("url") if isinstance(img_obj, dict) else None

        plot_obj = title_node.get("plot") or {}
        plot_text = ""
        if isinstance(plot_obj, dict):
            pt = plot_obj.get("plotText") or {}
            if isinstance(pt, dict):
                plot_text = pt.get("plainText") or ""

        genre_list = []
        for g in (title_node.get("genres", {}) or {}).get("genres", []):
            if isinstance(g, dict) and g.get("text"):
                genre_list.append(g.get("text"))

        runtime_str = ""
        dp = (title_node.get("runtime", {}) or {}).get(
            "displayableProperty", {})
        if isinstance(dp, dict):
            runtime_str = (dp.get("value", {}) or {}).get("plainText") or ""

        # Cast
        cast_list = []
        cast_credits = title_node.get("castV2", {})
        if isinstance(cast_credits, list):
            for c_group in cast_credits:
                if isinstance(c_group, dict):
                    for cred in c_group.get("credits", []):
                        cname = (cred.get("name", {}) or {}).get(
                            "nameText", {}).get("text")
                        if cname and cname not in cast_list:
                            cast_list.append(cname)
        elif isinstance(cast_credits, dict):
            for cred in cast_credits.get("credits", []):
                cname = (cred.get("name", {}) or {}).get(
                    "nameText", {}).get("text")
                if cname and cname not in cast_list:
                    cast_list.append(cname)

        # Directors / Crew
        director_list = []
        crew_credits = title_node.get("crewV2", {})
        if isinstance(crew_credits, list):
            for c_group in crew_credits:
                if isinstance(c_group, dict):
                    for cred in c_group.get("credits", []):
                        dname = (cred.get("name", {}) or {}).get(
                            "nameText", {}).get("text")
                        if dname and dname not in director_list:
                            director_list.append(dname)
        elif isinstance(crew_credits, dict):
            for cred in crew_credits.get("credits", []):
                dname = (cred.get("name", {}) or {}).get(
                    "nameText", {}).get("text")
                if dname and dname not in director_list:
                    director_list.append(dname)

        return {
            "title": orig_title or disp_title,
            "original_title": orig_title or disp_title,
            "display_title": disp_title or orig_title,
            "year": rel_year,
            "release_date": rel_year,
            "rating": rating or 0.0,
            "vote_average": rating or 0.0,
            "vote_count": vote_count or 0,
            "runtime": runtime_str,
            "genres": genre_list,
            "genres_str": ", ".join(genre_list),
            "overview": plot_text,
            "storyline": plot_text,
            "cast": [{"name": actor, "character": ""} for actor in cast_list],
            "actors": cast_list,
            "directors": director_list,
            "poster_url": poster_url,
            "poster_thumb_url": _make_imdb_thumbnail_url(poster_url, 140) if poster_url else None
        }

    except Exception:
        logger.exception("Error during IMDb GraphQL details | id=%s", imdb_id)
        return None
