# -*- coding: utf-8 -*-
from urllib3.exceptions import InsecureRequestWarning
from bs4 import BeautifulSoup
import urllib3
import requests
import json
import logging
import os
import random
import re
import time
import six
import warnings
warnings.filterwarnings(
    "ignore", message=".*soupsieve package is not installed.*", category=UserWarning)

try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus

urllib3.disable_warnings(InsecureRequestWarning)

DEBUG = False

logger = logging.getLogger("SubsSupportPro.TMDB")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [TMDB] %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
logger.setLevel(logging.DEBUG if DEBUG else logging.INFO)

# Default TMDB API key (shared across Enigma2 community skins/plugins)
DEFAULT_TMDB_API_KEY = "16c7b58c83085d17a3feb9f865339472"
TMDB_API_BASE = "https://api.themoviedb.org/3"
TMDB_IMG_BASE = "https://image.tmdb.org/t/p"

user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Mobile/15E148 Safari/604.1",
]


def get_tmdb_api_key():
    """Retrieve configured TMDB API key, falling back to community keys or files."""
    # 1. Check SubsSupportPro configuration
    try:
        from Components.config import config
        configured = getattr(config.plugins.subtitlesSupportPro, "settingsTMDBApiKey", None)
        if configured:
            val = str(configured.value).strip()
            if val:
                return val
    except Exception:
        pass

    # 2. Check environment variable
    env_key = os.environ.get("TMDB_API_KEY", "").strip()
    if env_key:
        return env_key

    # 3. Check known tmdb_key files on receiver
    key_paths = [
        "/etc/enigma2/subssupportpro/tmdb_key",
        "/etc/enigma2/tmdb_key",
        "/usr/lib/enigma2/python/Plugins/Extensions/Aglare/tmdb_key",
        "/usr/lib/enigma2/python/Plugins/Extensions/Aglarepli/tmdb_key",
        "/usr/lib/enigma2/python/Plugins/Extensions/CustomChannelSelection/tmdb_key",
        "/usr/lib/enigma2/python/Plugins/Extensions/LukaTV/tmdb_key",
    ]
    for kp in key_paths:
        try:
            if os.path.exists(kp):
                with open(kp, "r") as f:
                    content = f.read().strip()
                    if content:
                        return content
        except Exception:
            pass

    return DEFAULT_TMDB_API_KEY


def _json_to_unicode(data, indent=2):
    text = json.dumps(data, indent=indent, ensure_ascii=False)
    if six.PY2 and isinstance(text, six.binary_type):
        try:
            text = text.decode('utf-8')
        except Exception:
            try:
                text = text.decode('utf-8', 'ignore')
            except Exception:
                pass
    return text


def _write_json_utf8(filename, data, indent=2):
    text = _json_to_unicode(data, indent=indent)
    if isinstance(text, six.text_type):
        text = text.encode('utf-8')
    with open(filename, 'wb') as f:
        f.write(text)


def get_random_ua():
    return random.choice(user_agents)


def build_headers():
    return {
        "User-Agent": get_random_ua(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9,ar-EG;q=0.8,ar;q=0.7",
        "Referer": "https://www.themoviedb.org",
        "Connection": "keep-alive",
    }


headers = build_headers()


def _to_text(value):
    if value is None:
        return ""
    try:
        if isinstance(value, bytes):
            return value.decode("utf-8", "ignore")
    except Exception:
        pass
    try:
        return str(value)
    except Exception:
        return ""


def _normalize_search_text(value):
    text = _to_text(value)
    text = re.sub(r"\.[a-z0-9]{2,4}$", " ", text, flags=re.I)
    text = re.sub(r"[\._]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(
        r"\s*[\(\[\{]\s*(19|20)\d{2}\s*[\)\]\}]\s*$", "", text).strip()
    text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
    text = re.sub(
        r"\b(720p|1080p|2160p|4k|uhd|hdr|x264|x265|h264|h265|hevc|bluray|blu ray|web[- ]?dl|webrip|hdtv|dvdrip|brrip|proper|repack|extended|remastered)\b",
        " ",
        text,
        flags=re.I,
    )
    text = re.sub(r"\s+", " ", text).strip(" -._")
    return text


def _remove_trailing_media_hint(value):
    text = _normalize_search_text(value)
    # Event names often come as "Title movie" or "Title film".  Treat those
    # words as a search hint, not as part of the TMDB title, while keeping the
    # original query as a later fallback.
    cleaned = re.sub(r"\s+(movie|film|cinema)\s*$",
                     "", text, flags=re.I).strip()
    return cleaned or text


def _tmdb_search_urls(movie_title):
    original = _normalize_search_text(movie_title)
    cleaned = _remove_trailing_media_hint(original)
    queries = []
    for query in (cleaned, original):
        if query and query.lower() not in [q.lower() for q in queries]:
            queries.append(query)

    urls = []
    for query in queries:
        encoded = quote_plus(query)
        urls.append(
            ("movie", query, "https://www.themoviedb.org/search/movie?query={}".format(encoded)))
    for query in queries:
        encoded = quote_plus(query)
        urls.append(
            ("all", query, "https://www.themoviedb.org/search?query={}".format(encoded)))
    return urls


def _safe_request(url, context, timeout=10):
    try:
        logger.debug("HTTP GET start | context=%s | url=%s", context, url)
        response = requests.get(
            url, headers=build_headers(), verify=False, timeout=timeout)
        logger.debug(
            "HTTP GET done | context=%s | status=%s | url=%s",
            context,
            response.status_code,
            url,
        )
        response.raise_for_status()
        return response
    except requests.RequestException:
        logger.exception("HTTP GET failed | context=%s | url=%s", context, url)
        return None


def _safe_api_get(endpoint, params=None, context="tmdb api", timeout=10):
    """Query TMDB v3 API with error handling and automatic retry."""
    api_key = get_tmdb_api_key()
    if not api_key:
        logger.warning("No TMDB API key available for context=%s", context)
        return None

    if not endpoint.startswith("http"):
        url = "{}/{}".format(TMDB_API_BASE, endpoint.lstrip("/"))
    else:
        url = endpoint

    req_params = {"api_key": api_key}
    if params:
        req_params.update(params)

    headers = {
        "User-Agent": get_random_ua(),
        "Accept": "application/json",
        "Connection": "keep-alive"
    }

    for attempt in range(2):
        try:
            logger.debug("API GET start | attempt=%d | context=%s | url=%s", attempt + 1, context, url)
            response = requests.get(url, params=req_params, headers=headers, verify=False, timeout=timeout)
            logger.debug("API GET done | context=%s | status=%d", context, response.status_code)
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 429:
                # Rate limit, wait slightly and retry
                time.sleep(1)
                continue
            else:
                logger.warning("API GET error | status=%d | context=%s | text=%s",
                               response.status_code, context, response.text[:200])
                break
        except requests.RequestException as e:
            logger.warning("API GET failed | attempt=%d | context=%s | error=%s", attempt + 1, context, str(e))
            if attempt == 0:
                time.sleep(0.5)

    return None


def _extract_media_info_from_url(url):
    """Extract (media_type, tmdb_id) from TMDB web URL or string."""
    if not url:
        return "movie", ""
    url_str = str(url)
    m = re.search(r"/(movie|tv)/([0-9]+)", url_str)
    if m:
        return m.group(1), m.group(2)
    m_id = re.search(r"\b([0-9]{2,10})\b", url_str)
    if m_id:
        return "movie", m_id.group(1)
    return "movie", ""


def _parse_html(response, context):
    try:
        soup = BeautifulSoup(response.text, "html.parser")
        logger.debug("HTML parsed successfully | context=%s", context)
        return soup
    except Exception:
        logger.exception("HTML parse failed | context=%s", context)
        return None


def _class_list(tag):
    classes = tag.get("class", [])
    if isinstance(classes, list):
        return classes
    if classes:
        return str(classes).split()
    return []


def _has_class(tag, class_name):
    return class_name in _class_list(tag)


def _find_first_with_classes(root, tag_name, classes):
    if not root:
        return None
    for tag in root.find_all(tag_name):
        tag_classes = _class_list(tag)
        matched = True
        for class_name in classes:
            if class_name not in tag_classes:
                matched = False
                break
        if matched:
            return tag
    return None


def _find_all_with_classes(root, tag_name, classes):
    if not root:
        return []
    matches = []
    for tag in root.find_all(tag_name):
        tag_classes = _class_list(tag)
        matched = True
        for class_name in classes:
            if class_name not in tag_classes:
                matched = False
                break
        if matched:
            matches.append(tag)
    return matches


def _find_first_href_prefix(root, prefixes):
    if not root:
        return None
    for tag in root.find_all("a", href=True):
        href = tag.get("href", "")
        for prefix in prefixes:
            if href.startswith(prefix):
                return tag
    return None


def _find_release_date(root):
    return _find_first_with_classes(root, "span", ["release_date"]) or root.find("span", class_="release_date")


def _find_first_div_p(root):
    if not root:
        return None
    for div in root.find_all("div"):
        p = div.find("p")
        if p:
            return p
    return None


def _find_images_with_src_contains(root, needle):
    if not root:
        return []
    return [img for img in root.find_all("img", src=True) if needle in img["src"]]


def _find_people_profiles(root):
    return _find_all_with_classes(root, "li", ["profile"])


def extract_title_from_card(card):
    # Standard desktop layout: <h2> inside .details
    title_element = card.find("h2")
    if title_element:
        a_tag = title_element.find("a")
        if a_tag:
            return a_tag.get_text(strip=True)
        return title_element.get_text(strip=True)

    # Alternate layout: .title class
    title_div = card.find(class_="title")
    if title_div:
        a_tag = title_div.find("a")
        if a_tag:
            return a_tag.get_text(strip=True)
        return title_div.get_text(strip=True)

    # Direct anchor with class 'result'
    a_result = card.find("a", class_="result")
    if a_result:
        h2 = a_result.find("h2")
        if h2:
            return h2.get_text(strip=True)
        h3 = a_result.find("h3")
        if h3:
            return h3.get_text(strip=True)
        text = a_result.get_text(strip=True)
        if text:
            return text

    # Fallback: first link whose href starts with /movie/ or /tv/
    a_tag = _find_first_href_prefix(card, ["/movie/", "/tv/"])
    if a_tag and a_tag.has_attr("href"):
        url_parts = a_tag["href"].split("/")
        if len(url_parts) > 2:
            raw_title = url_parts[2].replace("-", " ")
            clean_title = re.sub(r"^\d+\s*", "", raw_title).strip()
            if clean_title:
                return clean_title.title()

    return "Unknown Title"


def extract_alternative_title(card):
    alt_title_span = card.find("span", class_="alt_title")
    if alt_title_span:
        return alt_title_span.get_text(strip=True)
    return None


def extract_poster_url(card):
    img_tag = card.find("img", class_="poster")
    if img_tag and img_tag.has_attr("src"):
        poster_url = img_tag["src"]
        replacements = {
            "w94_and_h141_bestv2": "w220_and_h330_face",
            "w130_and_h195_bestv2": "w220_and_h330_face",
            "w94_and_h141_face": "w220_and_h330_face",
            "w188_and_h282_face": "w220_and_h330_face",
        }
        for old, new in replacements.items():
            if old in poster_url:
                return poster_url.replace(old, new)
        return poster_url
    return None


def extract_tmdb_id(card):
    a_tag = _find_first_href_prefix(
        card, ["/movie/", "/tv/"]) or card.find("a", class_="result")
    if a_tag and a_tag.has_attr("href"):
        href = a_tag["href"]
        match = re.search(r"/(?:movie|tv)/(\d+)", href)
        if match:
            return match.group(1)
    return None


def _extract_media_type_from_url(url):
    if not url:
        return None
    match = re.search(r"/(movie|tv)/", url)
    if match:
        return match.group(1)
    return None


def _parse_tmdb_search_page(response, query, search_kind, source_index=0):
    logger.info("Parsing TMDB search page | query=%s | kind=%s",
                query, search_kind)
    if not response:
        return []

    soup = _parse_html(response, "tmdb search")
    if soup is None:
        return []

    results_container = soup.find(id="search_results") or soup.find(
        class_="search_results") or soup.find("section", class_="search_results")
    if not results_container:
        logger.warning(
            "TMDB search results container not found | query=%s | kind=%s", query, search_kind)
        return []

    movie_cards = _find_all_with_classes(results_container, "div", ["card", "style_1"]) or results_container.find_all(
        "div", class_="card")
    logger.info("Found %d TMDB cards | query=%s | kind=%s",
                len(movie_cards), query, search_kind)

    if not movie_cards:
        logger.warning(
            "No TMDB cards found | query=%s | kind=%s", query, search_kind)
        return []

    movies_data = []

    for index, card in enumerate(movie_cards, 1):
        try:
            movie = {}

            a_tag = _find_first_href_prefix(card, ["/movie/", "/tv/"])

            movie["title"] = extract_title_from_card(card)

            alt_title = extract_alternative_title(card)
            if alt_title:
                movie["alternative_title"] = alt_title

            if a_tag and a_tag.has_attr("href"):
                movie["url"] = "https://www.themoviedb.org" + a_tag["href"]
                inferred_media_type = _extract_media_type_from_url(
                    a_tag["href"])
                if inferred_media_type:
                    movie["media_type"] = inferred_media_type

            release_date = _find_release_date(card)
            if release_date:
                movie["release_date"] = release_date.get_text(" ", strip=True)

            overview_p = _find_first_div_p(card)
            if overview_p:
                overview_text = overview_p.get_text(" ", strip=True)
                if overview_text:
                    movie["overview"] = overview_text

            poster_url = extract_poster_url(card)
            if poster_url:
                movie["poster_url"] = poster_url

            if a_tag and a_tag.has_attr("data-media-type"):
                movie["media_type"] = a_tag["data-media-type"]

            if a_tag and a_tag.has_attr("data-media-adult"):
                movie["adult_content"] = a_tag["data-media-adult"] == "true"

            tmdb_id = extract_tmdb_id(card)
            if tmdb_id:
                movie["tmdb_id"] = tmdb_id

            movie["_source_query"] = query
            movie["_source_kind"] = search_kind
            movie["_source_index"] = source_index

            logger.debug(
                "Parsed card %d | title=%s | release_date=%s | tmdb_id=%s | media_type=%s",
                index,
                movie.get("title"),
                movie.get("release_date"),
                movie.get("tmdb_id"),
                movie.get("media_type"),
            )
            movies_data.append(movie)
        except Exception:
            logger.exception("Failed parsing movie card index=%d", index)

    return movies_data


def _tmdb_result_key(movie):
    media_type = movie.get("media_type", "")
    tmdb_id = movie.get("tmdb_id", "")
    url = movie.get("url", "")
    if media_type and tmdb_id:
        return media_type + ":" + str(tmdb_id)
    return url or (movie.get("title", "") + ":" + movie.get("release_date", ""))


def _simple_title(value):
    value = _normalize_search_text(value).lower()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _tmdb_score(movie, preferred_title):
    score = 0
    media_type = movie.get("media_type", "")
    if media_type == "movie":
        score += 100
    elif media_type == "tv":
        score -= 60
    if movie.get("_source_kind") == "movie":
        score += 30
    score -= int(movie.get("_source_index", 0)) * 5

    wanted = _simple_title(_remove_trailing_media_hint(preferred_title))
    title = _simple_title(movie.get("title", ""))
    alt_title = _simple_title(movie.get("alternative_title", ""))
    if wanted and title == wanted:
        score += 50
    elif wanted and alt_title == wanted:
        score += 40
    elif wanted and (title.startswith(wanted) or wanted.startswith(title)):
        score += 15

    if movie.get("poster_url"):
        score += 2
    if movie.get("release_date"):
        score += 2
    return score


def _search_tmdb_api(movie_title):
    """Primary search implementation using official TMDB v3 API."""
    original = _normalize_search_text(movie_title)
    cleaned = _remove_trailing_media_hint(original)
    queries = []
    for query in (cleaned, original):
        if query and query.lower() not in [q.lower() for q in queries]:
            queries.append(query)

    all_results = []
    seen = set()

    for source_index, query in enumerate(queries):
        logger.info("TMDB API search attempt | query=%s", query)

        # 1. First attempt movie search
        movie_data = _safe_api_get("search/movie", {"query": query, "include_adult": "true"}, "search/movie")
        if movie_data and movie_data.get("results"):
            for item in movie_data["results"]:
                movie = _format_api_item(item, default_media_type="movie", source_query=query,
                                         source_kind="movie", source_index=source_index)
                key = _tmdb_result_key(movie)
                if key and key in seen:
                    continue
                if key:
                    seen.add(key)
                all_results.append(movie)

            # If exact movie match found, prioritize and return early
            for m in all_results:
                if m.get("media_type") == "movie" and _simple_title(m.get("title", "")) == _simple_title(query):
                    all_results.sort(key=lambda item: _tmdb_score(item, movie_title), reverse=True)
                    return all_results

        # 2. Also search multi (includes TV shows, documentaries)
        multi_data = _safe_api_get("search/multi", {"query": query, "include_adult": "true"}, "search/multi")
        if multi_data and multi_data.get("results"):
            for item in multi_data["results"]:
                media_type = item.get("media_type")
                if media_type not in ("movie", "tv"):
                    continue
                movie = _format_api_item(item, default_media_type=media_type, source_query=query,
                                         source_kind="all", source_index=source_index)
                key = _tmdb_result_key(movie)
                if key and key in seen:
                    continue
                if key:
                    seen.add(key)
                all_results.append(movie)

    all_results.sort(key=lambda item: _tmdb_score(item, movie_title), reverse=True)
    return all_results


def _format_api_item(item, default_media_type="movie", source_query="", source_kind="movie", source_index=0):
    """Normalize raw TMDB API JSON item to match the format expected by SubsSupportPro."""
    media_type = item.get("media_type") or default_media_type
    tmdb_id = str(item.get("id", ""))
    title = item.get("title") or item.get("name") or "Unknown Title"
    alt_title = item.get("original_title") or item.get("original_name")
    release_date = item.get("release_date") or item.get("first_air_date") or ""
    overview = item.get("overview") or ""

    poster_path = item.get("poster_path")
    poster_url = "{}/w220_and_h330_face{}".format(TMDB_IMG_BASE, poster_path) if poster_path else None

    web_url = "https://www.themoviedb.org/{}/{}".format(media_type, tmdb_id)

    movie = {
        "title": title,
        "url": web_url,
        "media_type": media_type,
        "release_date": release_date,
        "overview": overview,
        "poster_url": poster_url,
        "adult_content": item.get("adult", False),
        "tmdb_id": tmdb_id,
        "_source_query": source_query,
        "_source_kind": source_kind,
        "_source_index": source_index,
    }
    if alt_title and alt_title != title:
        movie["alternative_title"] = alt_title

    return movie


def scrape_tmdb_movies(movie_title):
    logger.info("Searching TMDB movies | title=%s", movie_title)

    # 1. Try official TMDB API first (never blocked by Cloudflare/403)
    try:
        api_results = _search_tmdb_api(movie_title)
        if api_results:
            logger.info("TMDB API returned %d results", len(api_results))
            return api_results
    except Exception as e:
        logger.warning("TMDB API search failed: %s, falling back to web scraper", str(e))

    # 2. Fallback to website scraping (for offline or unconfigured environments)
    all_results = []
    seen = set()

    for source_index, (search_kind, query, url) in enumerate(_tmdb_search_urls(movie_title)):
        logger.info("TMDB web search attempt | original=%s | query=%s | kind=%s | url=%s",
                    movie_title, query, search_kind, url)
        response = _safe_request(url, "tmdb search")
        results = _parse_tmdb_search_page(
            response, query, search_kind, source_index)
        for movie in results:
            key = _tmdb_result_key(movie)
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            all_results.append(movie)

        if search_kind == "movie":
            for movie in all_results:
                if movie.get("media_type") == "movie" and _simple_title(movie.get("title", "")) == _simple_title(query):
                    all_results.sort(key=lambda item: _tmdb_score(
                        item, movie_title), reverse=True)
                    return all_results

    all_results.sort(key=lambda item: _tmdb_score(
        item, movie_title), reverse=True)
    return all_results


def scrape_movie_logos(movie_url):
    media_type, tmdb_id = _extract_media_info_from_url(movie_url)
    if tmdb_id:
        data = _safe_api_get("{}/{}/images".format(media_type, tmdb_id),
                             {"include_image_language": "en,null"}, "movie logos api")
        if data and "logos" in data:
            logos = []
            for logo in data["logos"]:
                fp = logo.get("file_path")
                if fp:
                    logos.append("{}/w500{}".format(TMDB_IMG_BASE, fp))
            if logos:
                return logos

    # Fallback to web scraping
    logos_url = movie_url + "/images/logos"
    try:
        time.sleep(0.5)
        response = _safe_request(logos_url, "movie logos")
        if not response:
            return []

        soup = _parse_html(response, "movie logos")
        if soup is None:
            return []

        logos_section = soup.find("section", class_="panel user_images")
        if not logos_section:
            logger.debug("No logos section found | movie_url=%s", movie_url)
            return []

        logo_images = []
        logo_elements = _find_images_with_src_contains(logos_section, "w500")

        for logo_element in logo_elements:
            if logo_element.has_attr("src"):
                logo_images.append(logo_element["src"])

        logger.debug("Scraped %d logos | movie_url=%s",
                     len(logo_images), movie_url)
        return logo_images

    except Exception:
        logger.exception("Error scraping logos | movie_url=%s", movie_url)
        return []


def scrape_movie_backdrops(movie_url):
    media_type, tmdb_id = _extract_media_info_from_url(movie_url)
    if tmdb_id:
        data = _safe_api_get("{}/{}/images".format(media_type, tmdb_id),
                             {"include_image_language": "en,null"}, "movie backdrops api")
        if data and "backdrops" in data:
            backdrops = []
            for bd in data["backdrops"]:
                fp = bd.get("file_path")
                if fp:
                    backdrops.append("{}/w500_and_h282_face{}".format(TMDB_IMG_BASE, fp))
            if backdrops:
                return backdrops

    # Fallback to web scraping
    backdrops_url = movie_url + "/images/backdrops"
    try:
        time.sleep(0.5)
        response = _safe_request(backdrops_url, "movie backdrops")
        if not response:
            return []

        soup = _parse_html(response, "movie backdrops")
        if soup is None:
            return []

        backdrops_section = soup.find("section", class_="panel user_images")
        if not backdrops_section:
            logger.debug(
                "No backdrops section found | movie_url=%s", movie_url)
            return []

        backdrop_images = []
        backdrop_elements = _find_images_with_src_contains(
            backdrops_section, "w500_and_h282_face")

        for backdrop_element in backdrop_elements:
            if backdrop_element.has_attr("src"):
                backdrop_images.append(backdrop_element["src"])

        logger.debug("Scraped %d backdrops | movie_url=%s",
                     len(backdrop_images), movie_url)
        return backdrop_images

    except Exception:
        logger.exception("Error scraping backdrops | movie_url=%s", movie_url)
        return []


def scrape_movie_posters(movie_url):
    media_type, tmdb_id = _extract_media_info_from_url(movie_url)
    if tmdb_id:
        data = _safe_api_get("{}/{}/images".format(media_type, tmdb_id),
                             {"include_image_language": "en,null"}, "movie posters api")
        if data and "posters" in data:
            posters = []
            for p in data["posters"]:
                fp = p.get("file_path")
                if fp:
                    posters.append("{}/w220_and_h330_face{}".format(TMDB_IMG_BASE, fp))
            if posters:
                return posters

    # Fallback to web scraping
    posters_url = movie_url + "/images/posters"
    try:
        time.sleep(0.5)
        response = _safe_request(posters_url, "movie posters")
        if not response:
            return []

        soup = _parse_html(response, "movie posters")
        if soup is None:
            return []

        posters_section = soup.find("section", class_="panel user_images")
        if not posters_section:
            logger.debug("No posters section found | movie_url=%s", movie_url)
            return []

        poster_images = []
        poster_elements = _find_images_with_src_contains(
            posters_section, "w220_and_h330_face")

        for poster_element in poster_elements:
            if poster_element.has_attr("src"):
                poster_images.append(poster_element["src"])

        logger.debug("Scraped %d posters | movie_url=%s",
                     len(poster_images), movie_url)
        return poster_images

    except Exception:
        logger.exception("Error scraping posters | movie_url=%s", movie_url)
        return []


def scrape_movie_trailers(movie_url):
    media_type, tmdb_id = _extract_media_info_from_url(movie_url)
    if tmdb_id:
        data = _safe_api_get("{}/{}/videos".format(media_type, tmdb_id), None, "movie trailers api")
        if data and "results" in data:
            trailers = []
            for v in data["results"]:
                key = v.get("key")
                site = v.get("site", "YouTube")
                t_item = {
                    "youtube_id": key,
                    "youtube_url": "https://www.youtube.com/watch?v={}".format(key) if key else "",
                    "title": v.get("name", ""),
                    "details": v.get("type", ""),
                    "site": site,
                    "channel": ""
                }
                trailers.append(t_item)
            if trailers:
                return trailers

    # Fallback to web scraping
    trailers_url = movie_url + "/videos?active_nav_item=Trailers"
    try:
        time.sleep(0.5)
        response = _safe_request(trailers_url, "movie trailers")
        if not response:
            return []

        soup = _parse_html(response, "movie trailers")
        if soup is None:
            return []

        trailers_section = soup.find("section", class_="panel video")
        if not trailers_section:
            logger.debug("No trailers section found | movie_url=%s", movie_url)
            return []

        trailers = []
        trailer_elements = trailers_section.find_all(
            "div", class_="video card default")

        for trailer_element in trailer_elements:
            trailer = {}

            play_button = trailer_element.find("a", class_="play_trailer")
            if play_button and play_button.has_attr("data-id"):
                trailer["youtube_id"] = play_button["data-id"]
                trailer["youtube_url"] = 'https://www.youtube.com/watch?v={}'.format(
                    play_button['data-id'])

            title_element = trailer_element.find("h2")
            if title_element:
                trailer["title"] = title_element.get_text(strip=True)

            sub_element = trailer_element.find("h3", class_="sub")
            if sub_element:
                trailer["details"] = sub_element.get_text(strip=True)

            if play_button and play_button.has_attr("data-site"):
                trailer["site"] = play_button["data-site"]

            channel_element = trailer_element.find("h4")
            if channel_element:
                trailer["channel"] = channel_element.get_text(strip=True)

            if trailer:
                trailers.append(trailer)

        logger.debug("Scraped %d trailers | movie_url=%s",
                     len(trailers), movie_url)
        return trailers

    except Exception:
        logger.exception("Error scraping trailers | movie_url=%s", movie_url)
        return []


def scrape_movie_cast(movie_url):
    media_type, tmdb_id = _extract_media_info_from_url(movie_url)
    if tmdb_id:
        data = _safe_api_get("{}/{}/credits".format(media_type, tmdb_id), None, "movie cast api")
        if data and "cast" in data:
            cast_list = []
            for c in data["cast"][:6]:
                profile_path = c.get("profile_path")
                profile_url = "{}/w132_and_h132_face{}".format(TMDB_IMG_BASE, profile_path) if profile_path else ""
                cast_list.append({
                    "name": c.get("name", ""),
                    "character": c.get("character", ""),
                    "profile_url": profile_url
                })
            if cast_list:
                return cast_list

    # Fallback to web scraping
    cast_url = movie_url + "/cast"
    try:
        time.sleep(0.5)
        response = _safe_request(cast_url, "movie cast")
        if not response:
            return []

        soup = _parse_html(response, "movie cast")
        if soup is None:
            return []

        cast_section = soup.find("section", class_="panel pad")
        if not cast_section:
            logger.warning("No cast section found | movie_url=%s", movie_url)
            return []

        cast = []
        cast_elements = cast_section.find_all("li", attrs={"data-order": True})

        for i, cast_element in enumerate(cast_elements[:6]):
            actor = {}

            info_div = cast_element.find("div", class_="info")
            if info_div:
                p_tag = info_div.find("p")
                if p_tag:
                    a_tag = p_tag.find("a")
                    if a_tag:
                        actor["name"] = a_tag.get_text(strip=True)

            character_element = cast_element.find("p", class_="character")
            if character_element:
                actor["character"] = character_element.get_text(strip=True)

            profile_img = cast_element.find("img", class_="profile")
            if profile_img and profile_img.has_attr("src"):
                profile_url = profile_img["src"]
                if "w66_and_h66_face" in profile_url:
                    profile_url = profile_url.replace(
                        "w66_and_h66_face", "w132_and_h132_face")
                actor["profile_url"] = profile_url

            if actor.get("name"):
                cast.append(actor)
            else:
                logger.warning(
                    "No name found for cast member index=%d | movie_url=%s", i, movie_url)

        logger.debug("Scraped %d cast members | movie_url=%s",
                     len(cast), movie_url)
        return cast

    except Exception:
        logger.exception("Error scraping cast | movie_url=%s", movie_url)
        return []


def _get_movie_details_api(movie_url):
    """Retrieve full movie/TV details using TMDB API (single request with append_to_response)."""
    media_type, tmdb_id = _extract_media_info_from_url(movie_url)
    if not tmdb_id:
        return None

    endpoint = "{}/{}".format(media_type, tmdb_id)
    params = {
        "append_to_response": "credits,images,videos",
        "include_image_language": "en,null"
    }
    data = _safe_api_get(endpoint, params=params, context="movie details api")
    if not data or not data.get("id"):
        return None

    details = {}
    title = data.get("title") or data.get("name") or "Unknown Title"
    details["title"] = title
    details["tagline"] = data.get("tagline") or ""
    details["overview"] = data.get("overview") or ""
    details["release_date"] = data.get("release_date") or data.get("first_air_date") or ""

    # Runtime
    runtime = data.get("runtime")
    if not runtime and data.get("episode_run_time"):
        r_list = data.get("episode_run_time")
        if isinstance(r_list, list) and r_list:
            runtime = r_list[0]
    details["runtime"] = str(runtime) if runtime else "N/A"

    # Genres
    genres = [g.get("name") for g in data.get("genres", []) if g.get("name")]
    details["genres"] = genres

    # Rating
    vote_average = data.get("vote_average", 0)
    details["rating"] = str(int(round(vote_average * 10))) if vote_average else "N/A"

    # Adult
    details["adult"] = data.get("adult", False)

    # Poster
    poster_path = data.get("poster_path")
    if poster_path:
        details["poster_url"] = "{}/w220_and_h330_face{}".format(TMDB_IMG_BASE, poster_path)

    # Images
    images = data.get("images", {})
    logos = []
    for logo_item in images.get("logos", []):
        fp = logo_item.get("file_path")
        if fp:
            logos.append("{}/w500{}".format(TMDB_IMG_BASE, fp))
    if logos:
        details["logo_urls"] = logos

    backdrops = []
    for bd in images.get("backdrops", []):
        fp = bd.get("file_path")
        if fp:
            backdrops.append("{}/w500_and_h282_face{}".format(TMDB_IMG_BASE, fp))
    if backdrops:
        details["backdrop_urls"] = backdrops

    posters = []
    for p in images.get("posters", []):
        fp = p.get("file_path")
        if fp:
            posters.append("{}/w220_and_h330_face{}".format(TMDB_IMG_BASE, fp))
    if posters:
        details["additional_poster_urls"] = posters

    # Trailers
    videos = data.get("videos", {}).get("results", [])
    trailers = []
    for v in videos:
        key = v.get("key")
        site = v.get("site", "YouTube")
        t_item = {
            "youtube_id": key,
            "youtube_url": "https://www.youtube.com/watch?v={}".format(key) if key else "",
            "title": v.get("name", ""),
            "details": v.get("type", ""),
            "site": site,
            "channel": ""
        }
        trailers.append(t_item)
    if trailers:
        details["trailers"] = trailers

    # Cast
    credits = data.get("credits", {})
    cast_list = []
    for c in credits.get("cast", [])[:6]:
        profile_path = c.get("profile_path")
        profile_url = "{}/w132_and_h132_face{}".format(TMDB_IMG_BASE, profile_path) if profile_path else ""
        cast_list.append({
            "name": c.get("name", ""),
            "character": c.get("character", ""),
            "profile_url": profile_url
        })
    if cast_list:
        details["cast"] = cast_list

    # Director / Creator
    if media_type == "tv" and data.get("created_by"):
        creators = [c.get("name") for c in data.get("created_by", []) if c.get("name")]
        if creators:
            details["director"] = creators[0]
    elif credits.get("crew"):
        directors = [c.get("name") for c in credits["crew"] if c.get("job") == "Director" and c.get("name")]
        if directors:
            details["director"] = directors[0]

    return details


def scrape_movie_details(movie_url):
    # 1. Try TMDB API first
    try:
        api_details = _get_movie_details_api(movie_url)
        if api_details:
            logger.info("Scraped movie details via TMDB API complete | movie_url=%s | fields=%s",
                        movie_url, sorted(api_details.keys()))
            return api_details
    except Exception as e:
        logger.warning("TMDB API details request failed: %s, falling back to web scraper", str(e))

    # 2. Fallback to web scraping
    try:
        logger.info("Scraping movie details | movie_url=%s", movie_url)
        response = _safe_request(movie_url, "movie details")
        if not response:
            return None

        soup = _parse_html(response, "movie details")
        if soup is None:
            return None

        details = {}

        title_element = soup.find("h2", class_="title")
        if title_element:
            details["title"] = title_element.get_text(strip=True)

        tagline_element = soup.find("h3", class_="tagline")
        if tagline_element:
            details["tagline"] = tagline_element.get_text(strip=True)

        overview_element = soup.find("div", class_="overview")
        if overview_element:
            details["overview"] = (
                overview_element.find("p").get_text(strip=True)
                if overview_element.find("p")
                else overview_element.get_text(strip=True)
            )

        release_date_element = soup.find("span", class_="release")
        if release_date_element:
            details["release_date"] = release_date_element.get_text(strip=True)

        runtime_element = soup.find("span", class_="runtime")
        if runtime_element:
            details["runtime"] = runtime_element.get_text(strip=True)

        genres = []
        genres_elements = soup.find("span", class_="genres")
        if genres_elements:
            for genre in genres_elements.find_all("a"):
                genres.append(genre.get_text(strip=True))
            details["genres"] = genres

        rating_element = soup.find("div", class_="user_score_chart")
        if rating_element and rating_element.has_attr("data-percent"):
            details["rating"] = rating_element["data-percent"]

        poster_element = soup.find("img", class_="poster")
        if poster_element and poster_element.has_attr("src"):
            details["poster_url"] = poster_element["src"]

        logos = scrape_movie_logos(movie_url)
        if logos:
            details["logo_urls"] = logos

        backdrops = scrape_movie_backdrops(movie_url)
        if backdrops:
            details["backdrop_urls"] = backdrops

        posters = scrape_movie_posters(movie_url)
        if posters:
            details["additional_poster_urls"] = posters

        trailers = scrape_movie_trailers(movie_url)
        if trailers:
            details["trailers"] = trailers

        cast = scrape_movie_cast(movie_url)
        if cast:
            details["cast"] = cast

        director_elements = _find_people_profiles(soup)
        for director_element in director_elements:
            job_element = director_element.find("p", class_="job")
            if job_element and "director" in job_element.get_text(strip=True).lower():
                name_element = director_element.find("p", class_="name")
                if name_element:
                    details["director"] = (
                        name_element.find("a").get_text(strip=True)
                        if name_element.find("a")
                        else name_element.get_text(strip=True)
                    )
                break

        logger.info(
            "Scraped movie details complete | movie_url=%s | fields=%s",
            movie_url,
            sorted(details.keys()),
        )
        return details

    except Exception:
        logger.exception(
            "Error scraping movie details | movie_url=%s", movie_url)
        return None


def main():
    title = input("Please enter movie name: ")

    try:
        movies = scrape_tmdb_movies(title)

        if not movies:
            print("No movies found!")
            return

        print('\nFound {} movies:\n'.format(len(movies)))

        for i, movie in enumerate(movies, 1):
            print('{}. {} ({})'.format(i, movie.get(
                'title', 'N/A'), movie.get('release_date', 'N/A')))

        selection = input(
            "\nEnter the number of the movie you want to scrape details for (or 'all' for all movies): ")

        if selection.lower() == "all":
            detailed_movies = []
            for i, movie in enumerate(movies, 1):
                print('Scraping details for movie {}/{}: {}'.format(i,
                      len(movies), movie.get('title', 'N/A')))
                if "url" in movie:
                    details = scrape_movie_details(movie["url"])
                    if details:
                        if "cast" in details:
                            for actor in details["cast"]:
                                if "profile_url" in actor and "w66_and_h66_face" in actor["profile_url"]:
                                    actor["profile_url"] = actor["profile_url"].replace(
                                        "w66_and_h66_face", "w132_and_h132_face")

                        merged_info = movie.copy()
                        merged_info.update(details)
                        detailed_movies.append(merged_info)

            filename = 'tmdb_{}_detailed_results.json'.format(
                title.replace(' ', '_'))
            _write_json_utf8(filename, detailed_movies)
            print('All detailed results saved to {}'.format(filename))
            logger.info("Saved all detailed results | file=%s | count=%d",
                        filename, len(detailed_movies))

        else:
            try:
                selection_idx = int(selection) - 1
                if 0 <= selection_idx < len(movies):
                    selected_movie = movies[selection_idx]
                    print('\nScraping details for: {}'.format(
                        selected_movie.get('title', 'N/A')))

                    if "url" in selected_movie:
                        details = scrape_movie_details(selected_movie["url"])
                        if details:
                            if "cast" in details:
                                for actor in details["cast"]:
                                    if "profile_url" in actor and "w66_and_h66_face" in actor["profile_url"]:
                                        actor["profile_url"] = actor["profile_url"].replace(
                                            "w66_and_h66_face", "w132_and_h132_face")

                            merged_info = selected_movie.copy()
                            merged_info.update(details)

                            year = ""
                            if "release_date" in merged_info:
                                year_match = re.search(
                                    r"\d{4}", merged_info["release_date"])
                                if year_match:
                                    year = '_{}'.format(year_match.group())

                            filename = 'tmdb_{}{}_details.json'.format(
                                merged_info.get('title', 'unknown').replace(' ', '_'), year)

                            print("\nDetailed Movie Information:")
                            print("=" * 50)
                            for key, value in merged_info.items():
                                if key == "cast":
                                    print("Cast:")
                                    for i, actor in enumerate(value, 1):
                                        print('  {}. {} as {}'.format(i, actor.get(
                                            'name', 'N/A'), actor.get('character', 'N/A')))
                                        if "profile_url" in actor:
                                            print('     Profile: {}'.format(
                                                actor['profile_url']))
                                elif key == "logo_urls":
                                    print("Logos:")
                                    for i, logo_url in enumerate(value, 1):
                                        print('  {}. {}'.format(i, logo_url))
                                elif key == "backdrop_urls":
                                    print("Backdrops:")
                                    for i, backdrop_url in enumerate(value, 1):
                                        print('  {}. {}'.format(
                                            i, backdrop_url))
                                elif key == "additional_poster_urls":
                                    print("Additional Posters:")
                                    for i, poster_url in enumerate(value, 1):
                                        print('  {}. {}'.format(i, poster_url))
                                elif key == "trailers":
                                    print("Trailers:")
                                    for i, trailer in enumerate(value, 1):
                                        print('  {}. {}'.format(
                                            i, trailer.get('title', 'N/A')))
                                        print('     YouTube ID: {}'.format(
                                            trailer.get('youtube_id', 'N/A')))
                                        print('     YouTube URL: {}'.format(
                                            trailer.get('youtube_url', 'N/A')))
                                        print('     Details: {}'.format(
                                            trailer.get('details', 'N/A')))
                                        print('     Site: {}'.format(
                                            trailer.get('site', 'N/A')))
                                        if "channel" in trailer:
                                            print('     Channel: {}'.format(
                                                trailer['channel']))
                                elif isinstance(value, list):
                                    print('{}: {}'.format(key.replace(
                                        '_', ' ').title(), ', '.join(value)))
                                else:
                                    print('{}: {}'.format(
                                        key.replace('_', ' ').title(), value))

                            save = input(
                                "\nDo you want to save the detailed results to a JSON file? (y/n): ")
                            if save.lower() == "y":
                                _write_json_utf8(filename, merged_info)
                                print(
                                    'Detailed results saved to {}'.format(filename))
                                logger.info(
                                    "Saved detailed result | file=%s | title=%s", filename, merged_info.get("title"))
                        else:
                            print("Failed to scrape detailed information.")
                    else:
                        print("No URL found for the selected movie.")
                else:
                    print("Invalid selection.")
            except ValueError:
                print("Please enter a valid number or 'all'.")

    except requests.RequestException as e:
        print('Error making request: {}'.format(e))
        logger.exception("Request error in main")
    except Exception as e:
        print('An error occurred: {}'.format(e))
        logger.exception("Unhandled error in main")


if __name__ == "__main__":
    main()
