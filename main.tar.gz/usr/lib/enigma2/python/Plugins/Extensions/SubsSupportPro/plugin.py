# -*- coding: utf-8 -*-
from __future__ import absolute_import

import logging
import os
from xml.etree import ElementTree as ET

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import six
from twisted.web.client import getPage

from enigma import eTimer, getDesktop
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.PluginComponent import PluginDescriptor
from Components.Sources.List import List
from Components.config import config
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists
from .e2_utils import load_subskin, is4K, is2K, isFullHD
from .compat import eConnectCallback, SafeQuitMainloop

from . import _
from .subtitles import (
    E2SubsSeeker, SubsProSearch, initSubsProSettings, SubsProSetupGeneral,
    SubsProSearchSettings, SubsProSetupExternal, SubsProSetupEmbedded
)
from .subtitlesdvb import SubsProSupportDVB, SubsProSetupDVBPlayer

# Execute logic ONLY after all imports are safely loaded
try:
    from .version import VER
except ImportError:
    VER = "1.3.0"

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
log = logging.getLogger("SubsSupportPro")


def openSubtitlesSearch(session, **kwargs):
    settings = initSubsProSettings().search
    eventList = []
    eventNow = session.screen["Event_Now"].getEvent()
    eventNext = session.screen["Event_Next"].getEvent()
    if eventNow:
        eventList.append(eventNow.getEventName())
    if eventNext:
        eventList.append(eventNext.getEventName())

    # If no events found, try to use the channel name as fallback
    if not eventList:
        try:
            service = session.nav.getCurrentService()
            info = service and service.info()
            if info:
                channel_name = info.getName()
                if channel_name:
                    eventList.append(channel_name)
                    print('[SubsSupport] Using channel name as fallback: {}'.format(
                        channel_name))
        except Exception as e:
            print('[SubsSupport] Error getting channel name: {}'.format(e))

    session.open(SubsProSearch, E2SubsSeeker(session, settings),
                 settings, searchTitles=eventList, standAlone=True)


def openSubtitlesPlayer(session, **kwargs):
    SubsProSupportDVB(session)


def openSubsProSupportSettings(session, **kwargs):
    settings = initSubsProSettings()
    session.open(SubsProSupportSettings, settings, settings.search,
                 settings.external, settings.embedded, config.plugins.subsSupportPro.dvb)


class SubsProSupportSettings(Screen):

    def __init__(self, session, generalSettings, searchSettings, externalSettings, embeddedSettings, dvbSettings):

        try:
            if is4K():
                skin_id = "SubsProSupportSettings_4k"
            elif is2K():
                skin_id = "SubsProSupportSettings_2k"
            elif isFullHD():
                skin_id = "SubsProSupportSettings_fhd"
            else:
                skin_id = "SubsProSupportSettings_hd"
            self.skin = load_subskin(skin_id)

        except Exception:
            pass
        Screen.__init__(self, session)
        self.generalSettings = generalSettings
        self.searchSettings = searchSettings
        self.externalSettings = externalSettings
        self.embeddedSettings = embeddedSettings
        self.dvbSettings = dvbSettings
        self.new_version = None
        self.new_description = None

        # Get backup path from config - with proper error handling
        try:
            self.settings_backup_path = self.generalSettings.settingsBackupPath.getValue()
            self.settings_backup_file = os.path.join(
                self.settings_backup_path, "settings_backup.json")
        except AttributeError:
            # Fallback to default path if setting is missing
            log.error(
                "settingsBackupPath not found in generalSettings, using default")
            self.settings_backup_path = "/etc/enigma2/subssupportpro"
            self.settings_backup_file = os.path.join(
                self.settings_backup_path, "settings_backup.json")

        menu_items = [
            (_("General settings"), "general"),
            (_("External subtitles settings"), "external"),
            (_("Embedded subtitles settings"), "embedded"),
            (_("Search settings"), "search"),
            (_("DVB player settings"), "dvb"),
            (_("Backup settings"), "backup"),
            (_("Restore settings"), "restore")
        ]

        self["menuList"] = List(menu_items)
        self["update_status"] = Label("")
        self._setUpdateStatus(_("Checking for update..."))
        self["actionmap"] = ActionMap(["OkCancelActions", "DirectionActions"],
                                      {
            "up": self["menuList"].selectPrevious,
            "down": self["menuList"].selectNext,
            "ok": self.confirmSelection,
            "cancel": self.close,
        })
        self.onLayoutFinish.append(self.setWindowTitle)
        self.onFirstExecBegin.append(self.checkUpdates)

    def _setUpdateStatus(self, text):
        try:
            self["update_status"].setText(text)
        except Exception:
            pass

    def setWindowTitle(self):
        self.setup_title = _("SubsSupportPro settings")
        self.setTitle('{} v{}'.format(self.setup_title, VER))

    def confirmSelection(self):
        selection = self["menuList"].getCurrent()[1]
        if selection == "general":
            self.openGeneralSettings()
        elif selection == "external":
            self.openExternalSettings()
        elif selection == "embedded":
            self.openEmbeddedSettings()
        elif selection == "search":
            self.openSearchSettings()
        elif selection == "dvb":
            self.openDVBPlayerSettings()
        elif selection == "backup":
            self.backupSettings()
        elif selection == "restore":
            self.restoreSettings()  # Changed from _confirmRestore to restoreSettings

    def openGeneralSettings(self):
        self.session.open(SubsProSetupGeneral, self.generalSettings)

    def openSearchSettings(self):
        seeker = E2SubsSeeker(self.session, self.searchSettings, True)
        self.session.open(SubsProSearchSettings,
                          self.searchSettings, seeker, True)

    def openExternalSettings(self):
        self.session.open(SubsProSetupExternal, self.externalSettings)

    def openEmbeddedSettings(self):
        self.session.open(SubsProSetupEmbedded, self.embeddedSettings)

    def openDVBPlayerSettings(self):
        self.session.open(SubsProSetupDVBPlayer, self.dvbSettings)

    def backupSettings(self):
        try:
            # Get the backup path from config
            backup_path = self.generalSettings.settingsBackupPath.getValue()
            backup_file = os.path.join(backup_path, "settings_backup.json")

            # Create backup directory if it doesn't exist
            if not os.path.exists(backup_path):
                os.makedirs(backup_path)

            # Verify we can write to the directory
            test_file = os.path.join(backup_path, "test.tmp")
            try:
                with open(test_file, 'w') as f:
                    f.write("test")
                os.remove(test_file)
            except IOError as e:
                raise Exception(
                    _("Cannot write to backup directory: %s") % str(e))

            # Extract all subtitlesSupportPro settings
            settings_file = '/etc/enigma2/settings'
            if not fileExists(settings_file):
                raise Exception(_("Settings file not found"))

            # Extract all settings for our plugin
            with open(settings_file, 'r') as f, open(backup_file, 'w') as backup:
                for line in f:
                    if line.startswith('config.plugins.subtitlesSupportPro.'):
                        backup.write(line)

            # Verify backup was created
            if not fileExists(backup_file):
                raise Exception(_("Backup file creation failed"))
            if os.path.getsize(backup_file) == 0:
                raise Exception(_("Backup file is empty - no settings found"))

            self.session.open(MessageBox, _(
                "Settings backup completed successfully!"), MessageBox.TYPE_INFO)
        except Exception as e:
            log.error("Backup failed: %s", str(e), exc_info=True)
            self.session.open(MessageBox, _("Backup failed!") +
                              "\n" + str(e), MessageBox.TYPE_ERROR)

    def restoreSettings(self):
        backup_path = self.generalSettings.settingsBackupPath.getValue()
        backup_file = os.path.join(backup_path, "settings_backup.json")

        if not fileExists(backup_file):
            self.session.open(MessageBox, _(
                "No backup file found at: %s") % backup_file, MessageBox.TYPE_ERROR)
            return

        message = _(
            "Are you sure you want to restore settings from:\n%s\n\nEnigma2 will restart to apply changes.") % backup_file
        self.session.openWithCallback(
            self._performRestore, MessageBox, message, MessageBox.TYPE_YESNO)

    def _performRestore(self, answer):
        if not answer:
            return

        backup_path = self.generalSettings.settingsBackupPath.getValue()
        import os
        backup_file = os.path.join(backup_path, "settings_backup.json")

        try:
            from Tools.Directories import fileExists
            if not fileExists(backup_file):
                self.session.open(MessageBox, _(
                    "Backup file no longer exists!"), MessageBox.TYPE_ERROR)
                return

            # 1. Read backup lines
            with open(backup_file, 'r') as f:
                backup_lines = [line for line in f if line.startswith(
                    'config.plugins.subtitlesSupportPro.')]

            if not backup_lines:
                self.session.open(MessageBox, _(
                    "Backup file is empty or invalid!"), MessageBox.TYPE_ERROR)
                return

            # 2. Modify /etc/enigma2/settings directly
            settings_file = '/etc/enigma2/settings'
            if fileExists(settings_file):
                with open(settings_file, 'r') as f:
                    current_lines = f.readlines()

                # Filter out current subssupportpro settings
                new_lines = [line for line in current_lines if not line.startswith(
                    'config.plugins.subtitlesSupportPro.')]

                # Append backup settings
                new_lines.extend(backup_lines)

                # Write back
                with open(settings_file, 'w') as f:
                    f.writelines(new_lines)

            # 3. Reload config in memory from the modified file so Enigma2 saves the restored values on exit
            from Components.config import configfile
            configfile.load()
            configfile.save()

            # 4. Restart Enigma2 safely via Python mainloop
            self.session.open(MessageBox, _(
                "Settings restored successfully.\nRestarting GUI..."), MessageBox.TYPE_INFO, timeout=3)

            self.restartTimer = eTimer()
            try:
                # DreamOS compatible timer
                self.restartTimer_conn = eConnectCallback(
                    self.restartTimer.timeout, self._restartEnigma)
            except Exception:
                try:
                    # Alternative DreamOS import
                    self.restartTimer_conn = eConnectCallback(
                        self.restartTimer.timeout, self._restartEnigma)
                except Exception:
                    # OpenSource compatible timer
                    self.restartTimer.callback.append(self._restartEnigma)

            self.restartTimer.start(3000, True)

        except Exception as e:
            import logging
            log = logging.getLogger("SubsSupportPro")
            log.error("Restore failed: %s", str(e), exc_info=True)
            self.session.open(MessageBox, _("Restore failed!") +
                              "\n" + str(e), MessageBox.TYPE_ERROR)

    def _restartEnigma(self):
        SafeQuitMainloop(self.session, 3)

    def checkUpdates(self):
        try:
            self._setUpdateStatus(_("Checking for update..."))
            url = b"https://raw.githubusercontent.com/popking159/SubsSupportPro/main/version.txt"
            getPage(url, timeout=10).addCallback(
                self.parseUpdateData).addErrback(self.updateError)
        except Exception as e:
            log.error("Update check error: %s", str(e))
            self._setUpdateStatus(_("Update check failed"))

    def updateError(self, error):
        log.error("Failed to check for updates: %s", str(error))
        self._setUpdateStatus(_("Update check failed"))

    def parseUpdateData(self, data):
        if six.PY3:
            data = data.decode("utf-8")
        else:
            data = data.encode("utf-8")

        if data:
            lines = data.split("\n")
            for line in lines:
                if line.startswith("version="):
                    self.new_version = line.split(
                        "'")[1] if "'" in line else line.split('"')[1]
                if line.startswith("description="):
                    self.new_description = line.split(
                        "'")[1] if "'" in line else line.split('"')[1]
                    break

        # Helper to safely and accurately compare version numbers
        def is_newer_version(new_ver, current_ver):
            try:
                # Convert strings like "1.10.1" into numeric tuples (1, 10, 1) for accurate math comparison
                new_tuple = tuple(map(int, new_ver.split('.')))
                curr_tuple = tuple(map(int, current_ver.split('.')))
                return new_tuple > curr_tuple
            except Exception:
                # Fallback to standard string comparison if versions contain letters (e.g., "1.0-rc1")
                return new_ver > current_ver

        if self.new_version and is_newer_version(self.new_version, VER):
            self._setUpdateStatus(_("Update available"))
            message = _("New version %s is available.\n\n%s\n\nDo you want to install now?") % (
                self.new_version, self.new_description)
            self.session.openWithCallback(
                self.installUpdate,
                MessageBox,
                message,
                MessageBox.TYPE_YESNO,
                timeout=10
            )
        else:
            self._setUpdateStatus(_("Plugin up to date"))

    def installUpdate(self, answer=False):
        if answer:
            self._setUpdateStatus(_("Downloading update..."))
            cmd = 'wget -qO - https://raw.githubusercontent.com/popking159/SubsSupportPro/refs/heads/main/myinstaller.sh | /bin/sh'
            self.session.open(Console, title=_("Installing update..."), cmdlist=[
                              cmd], closeOnSuccess=False)


def Plugins(**kwargs):
    screenwidth = getDesktop(0).size().width()
    if screenwidth and screenwidth >= 3840:
        iconSET = 'img/ss_set_4K.png'  # 300x120
        iconDWN = 'img/ss_dwn_4K.png'
        iconPLY = 'img/ss_ply_4K.png'
    elif screenwidth and screenwidth >= 2560:
        iconSET = 'img/ss_set_2K.png'  # 200x80
        iconDWN = 'img/ss_dwn_2K.png'
        iconPLY = 'img/ss_ply_2K.png'
    elif screenwidth and screenwidth >= 1920:
        iconSET = 'img/ss_set_FHD.png'  # 150x60
        iconDWN = 'img/ss_dwn_FHD.png'
        iconPLY = 'img/ss_ply_FHD.png'
    else:
        iconSET = 'img/ss_set_HD.png'  # 100x40
        iconDWN = 'img/ss_dwn_HD.png'
        iconPLY = 'img/ss_ply_HD.png'

    return [
        PluginDescriptor(name=_('SubsSupportPro settings'), icon=iconSET, description=_(
            'Change SubsSupportPro settings'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubsProSupportSettings),
        PluginDescriptor(name=_('SubsSupportPro downloader'), icon=iconDWN, description=_(
            'Download subtitles for your videos'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubtitlesSearch),
        PluginDescriptor(name=_('SubsSupportPro DVB player'), icon=iconPLY, description=_(
            'watch DVB broadcast with subtitles'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubtitlesPlayer),
        PluginDescriptor(name=_('SubsSupportPro settings'),
                         where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubsProSupportSettings),
        PluginDescriptor(name=_('SubsSupportPro downloader'),
                         where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubtitlesSearch),
        PluginDescriptor(name=_('SubsSupportPro DVB player'),
                         where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubtitlesPlayer)
    ]
