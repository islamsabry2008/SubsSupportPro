# -*- coding: utf-8 -*-
from __future__ import absolute_import

import logging
import os

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning  # type: ignore

from enigma import eTimer, getDesktop  # type: ignore
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.PluginComponent import PluginDescriptor
from Components.Sources.List import List
from Components.config import config
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists
from .e2_utils import load_subskin, is4K, is2K, isFullHD
from .compat import eConnectCallback, SafeQuitMainloop
from .version import PLUGIN_VERSION_TITLE
from .update import PluginUpdater

from . import _
from .subtitles import (
    E2SubsSeeker, SubsProSearch, initSubsProSettings, SubsProSetupGeneral,
    SubsProSearchSettings, SubsProSetupExternal, SubsProSetupEmbedded
)
from .subtitlesdvb import SubsProSupportDVB, SubsProSetupDVBPlayer
from .webui import start_webui


requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
log = logging.getLogger("SubsSupportPro")


def openSubtitlesSearch(session, **kwargs):
    settings = initSubsProSettings().search
    eventList = []
    eventNow = session.screen["Event_Now"].getEvent()
    eventNext = session.screen["Event_Next"].getEvent()
    if eventNow:
        eventList.append(eventNow.getEventName())
    if eventNext:
        eventList.append(eventNext.getEventName())

    if not eventList:
        try:
            service = session.nav.getCurrentService()
            info = service and service.info()
            if info:
                channel_name = info.getName()
                if channel_name:
                    eventList.append(channel_name)
                    print('[SubsSupport] Using channel name as fallback: {}'.format(
                        channel_name))
        except Exception as e:
            print('[SubsSupport] Error getting channel name: {}'.format(e))

    if eventList:
        import re
        original_title = eventList[0]

        match = re.search(r'(?i)[S]([0-9]+)\s*[E]([0-9]+)', original_title)
        if not match:
            match = re.search(
                r'(?i)(?:\b|_)([0-9]{1,2})x([0-9]{1,2})(?:\b|_)', original_title)
        if not match:
            match = re.search(
                r'(?i)(?:\b|_)([0-9]{1,2})-([0-9]{1,2})(?:\b|_)', original_title)

        if match:
            s_num, e_num = match.groups()
            clean_title = original_title[:match.start()].replace(
                '.', ' ').replace('_', ' ').strip()
            clean_title = re.sub(r'[-:]$', '', clean_title).strip()

            if clean_title:
                normalized_title = "%s S%02dE%02d" % (
                    clean_title, int(s_num), int(e_num))
                eventList[0] = normalized_title
                print('[SubsSupport] Normalized TV Show pattern for core parser: {}'.format(
                    normalized_title))

    session.open(SubsProSearch, E2SubsSeeker(session, settings),
                 settings, searchTitles=eventList, standAlone=True)


def openSubtitlesPlayer(session, **kwargs):
    SubsProSupportDVB(session)


def openSubsProSupportSettings(session, **kwargs):
    settings = initSubsProSettings()
    session.open(SubsProSupportSettings, settings, settings.search,
                 settings.external, settings.embedded, config.plugins.subsSupportPro.dvb)


class SubsProSupportSettings(Screen):

    def __init__(self, session, generalSettings, searchSettings, externalSettings, embeddedSettings, dvbSettings):
        try:
            if is4K():
                skin_id = "SubsProSupportSettings_4k"
            elif is2K():
                skin_id = "SubsProSupportSettings_2k"
            elif isFullHD():
                skin_id = "SubsProSupportSettings_fhd"
            else:
                skin_id = "SubsProSupportSettings_hd"
            self.skin = load_subskin(skin_id)
        except Exception:
            pass

        Screen.__init__(self, session)
        self.generalSettings = generalSettings
        self.searchSettings = searchSettings
        self.externalSettings = externalSettings
        self.embeddedSettings = embeddedSettings
        self.dvbSettings = dvbSettings

        try:
            self.settings_backup_path = self.generalSettings.settingsBackupPath.getValue()
            self.settings_backup_file = os.path.join(
                self.settings_backup_path, "settings_backup.json")
        except AttributeError:
            log.error(
                "settingsBackupPath not found in generalSettings, using default")
            self.settings_backup_path = "/etc/enigma2/subssupportpro"
            self.settings_backup_file = os.path.join(
                self.settings_backup_path, "settings_backup.json")

        menu_items = [
            (_("General settings"), "general"),
            (_("External subtitles settings"), "external"),
            (_("Embedded subtitles settings"), "embedded"),
            (_("Search settings"), "search"),
            (_("DVB player settings"), "dvb"),
            (_("Backup settings"), "backup"),
            (_("Restore settings"), "restore")
        ]

        self["menuList"] = List(menu_items)
        self["update_status"] = Label("")

        self["actionmap"] = ActionMap(["OkCancelActions", "DirectionActions"],
                                      {
            "up": self["menuList"].selectPrevious,
            "down": self["menuList"].selectNext,
            "ok": self.confirmSelection,
            "cancel": self.close,
        })

        self.onLayoutFinish.append(self.setWindowTitle)
        self.onFirstExecBegin.append(self.startUpdater)

    def setWindowTitle(self):
        self.setTitle(PLUGIN_VERSION_TITLE + _(" settings"))

    def startUpdater(self):
        # Instantiate the new updater from update.py
        self.updater = PluginUpdater(self.session, self)

    def setUpdateStatus(self, text):
        # Exposed method for update.py to update the UI status label
        try:
            self["update_status"].setText(text)
        except Exception:
            pass

    def confirmSelection(self):
        selection = self["menuList"].getCurrent()[1]
        if selection == "general":
            self.openGeneralSettings()
        elif selection == "external":
            self.openExternalSettings()
        elif selection == "embedded":
            self.openEmbeddedSettings()
        elif selection == "search":
            self.openSearchSettings()
        elif selection == "dvb":
            self.openDVBPlayerSettings()
        elif selection == "backup":
            self.backupSettings()
        elif selection == "restore":
            self.restoreSettings()

    def openGeneralSettings(self):
        self.session.open(SubsProSetupGeneral, self.generalSettings)

    def openSearchSettings(self):
        seeker = E2SubsSeeker(self.session, self.searchSettings, True)
        self.session.open(SubsProSearchSettings,
                          self.searchSettings, seeker, True)

    def openExternalSettings(self):
        self.session.open(SubsProSetupExternal, self.externalSettings)

    def openEmbeddedSettings(self):
        self.session.open(SubsProSetupEmbedded, self.embeddedSettings)

    def openDVBPlayerSettings(self):
        self.session.open(SubsProSetupDVBPlayer, self.dvbSettings)

    def backupSettings(self):
        try:
            backup_path = self.generalSettings.settingsBackupPath.getValue()
            backup_file = os.path.join(backup_path, "settings_backup.json")

            if not os.path.exists(backup_path):
                os.makedirs(backup_path)

            test_file = os.path.join(backup_path, "test.tmp")
            try:
                with open(test_file, 'w') as f:
                    f.write("test")
                os.remove(test_file)
            except IOError as e:
                raise Exception(
                    _("Cannot write to backup directory: %s") % str(e))

            settings_file = '/etc/enigma2/settings'
            if not fileExists(settings_file):
                raise Exception(_("Settings file not found"))

            with open(settings_file, 'r') as f, open(backup_file, 'w') as backup:
                for line in f:
                    if line.startswith('config.plugins.subtitlesSupportPro.'):
                        backup.write(line)

            if not fileExists(backup_file):
                raise Exception(_("Backup file creation failed"))
            if os.path.getsize(backup_file) == 0:
                raise Exception(_("Backup file is empty - no settings found"))

            self.session.open(MessageBox, _(
                "Settings backup completed successfully!"), MessageBox.TYPE_INFO)
        except Exception as e:
            log.error("Backup failed: %s", str(e), exc_info=True)
            self.session.open(MessageBox, _("Backup failed!") +
                              "\n" + str(e), MessageBox.TYPE_ERROR)

    def restoreSettings(self):
        backup_path = self.generalSettings.settingsBackupPath.getValue()
        backup_file = os.path.join(backup_path, "settings_backup.json")

        if not fileExists(backup_file):
            self.session.open(MessageBox, _(
                "No backup file found at: %s") % backup_file, MessageBox.TYPE_ERROR)
            return

        message = _(
            "Are you sure you want to restore settings from:\n%s\n\nEnigma2 will restart to apply changes.") % backup_file
        self.session.openWithCallback(
            self._performRestore, MessageBox, message, MessageBox.TYPE_YESNO)

    def _performRestore(self, answer):
        if not answer:
            return

        backup_path = self.generalSettings.settingsBackupPath.getValue()
        import os
        backup_file = os.path.join(backup_path, "settings_backup.json")

        try:
            from Tools.Directories import fileExists
            if not fileExists(backup_file):
                self.session.open(MessageBox, _(
                    "Backup file no longer exists!"), MessageBox.TYPE_ERROR)
                return

            with open(backup_file, 'r') as f:
                backup_lines = [line for line in f if line.startswith(
                    'config.plugins.subtitlesSupportPro.')]

            if not backup_lines:
                self.session.open(MessageBox, _(
                    "Backup file is empty or invalid!"), MessageBox.TYPE_ERROR)
                return

            settings_file = '/etc/enigma2/settings'
            if fileExists(settings_file):
                with open(settings_file, 'r') as f:
                    current_lines = f.readlines()

                new_lines = [line for line in current_lines if not line.startswith(
                    'config.plugins.subtitlesSupportPro.')]

                new_lines.extend(backup_lines)

                with open(settings_file, 'w') as f:
                    f.writelines(new_lines)

            from Components.config import configfile
            configfile.load()
            configfile.save()

            self.session.open(MessageBox, _(
                "Settings restored successfully.\nRestarting GUI..."), MessageBox.TYPE_INFO, timeout=3)

            self.restartTimer = eTimer()
            try:
                self.restartTimer_conn = eConnectCallback(
                    self.restartTimer.timeout, self._restartEnigma)
            except Exception:
                try:
                    self.restartTimer_conn = eConnectCallback(
                        self.restartTimer.timeout, self._restartEnigma)
                except Exception:
                    self.restartTimer.callback.append(self._restartEnigma)

            self.restartTimer.start(3000, True)

        except Exception as e:
            import logging
            log = logging.getLogger("SubsSupportPro")
            log.error("Restore failed: %s", str(e), exc_info=True)
            self.session.open(MessageBox, _("Restore failed!") +
                              "\n" + str(e), MessageBox.TYPE_ERROR)

    def _restartEnigma(self):
        SafeQuitMainloop(self.session, 3)


def autostart(reason, **kwargs):
    if reason == 0:
        try:
            start_webui()
        except Exception as e:
            print("[SubsSupportPro] WebUI failed to start:", e)


def Plugins(**kwargs):
    screenwidth = getDesktop(0).size().width()
    if screenwidth and screenwidth >= 3840:
        iconSET = 'img/ss_set_4K.png'
        iconDWN = 'img/ss_dwn_4K.png'
        iconPLY = 'img/ss_ply_4K.png'
    elif screenwidth and screenwidth >= 2560:
        iconSET = 'img/ss_set_2K.png'
        iconDWN = 'img/ss_dwn_2K.png'
        iconPLY = 'img/ss_ply_2K.png'
    elif screenwidth and screenwidth >= 1920:
        iconSET = 'img/ss_set_FHD.png'
        iconDWN = 'img/ss_dwn_FHD.png'
        iconPLY = 'img/ss_ply_FHD.png'
    else:
        iconSET = 'img/ss_set_HD.png'
        iconDWN = 'img/ss_dwn_HD.png'
        iconPLY = 'img/ss_ply_HD.png'

    return [
        PluginDescriptor(
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        ),
        PluginDescriptor(name=_('SubsSupportPro settings'), icon=iconSET, description=_(
            'Change SubsSupportPro settings'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubsProSupportSettings),
        PluginDescriptor(name=_('SubsSupportPro downloader'), icon=iconDWN, description=_(
            'Download subtitles for your videos'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubtitlesSearch),
        PluginDescriptor(name=_('SubsSupportPro DVB player'), icon=iconPLY, description=_(
            'watch DVB broadcast with subtitles'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubtitlesPlayer),
        PluginDescriptor(name=_('SubsSupportPro settings'),
                         where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubsProSupportSettings),
        PluginDescriptor(name=_('SubsSupportPro downloader'),
                         where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubtitlesSearch),
        PluginDescriptor(name=_('SubsSupportPro DVB player'),
                         where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubtitlesPlayer)
    ]
