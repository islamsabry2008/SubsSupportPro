# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
import requests
import json
import re
import os

# Initialize the persistent session object
session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
})

SEARCH_URL = "https://search.justsubtitles.com/api/search"
BASE_URL = "https://www.justsubtitles.com"
DL_BASE = "https://dl.subdl.com"

# Comprehensive language mapping. Supports full E2 names and ISO codes.
SUPPORTED_LANGUAGES = [
    {"code": "AR", "language": "Arabic", "aliases": ["ar", "arabic"]},
    {"code": "EN", "language": "English", "aliases": ["en", "english"]},
    {"code": "FR", "language": "French", "aliases": ["fr", "french"]},
    {"code": "ES", "language": "Spanish", "aliases": ["es", "spanish"]},
    {"code": "DE", "language": "German", "aliases": ["de", "german"]},
    {"code": "IT", "language": "Italian", "aliases": ["it", "italian"]},
    {"code": "PT", "language": "Portuguese", "aliases": ["pt", "portuguese"]},
    {"code": "NL", "language": "Dutch", "aliases": ["nl", "dutch"]},
    {"code": "PL", "language": "Polish", "aliases": ["pl", "polish"]},
    {"code": "TR", "language": "Turkish", "aliases": ["tr", "turkish"]},
    {"code": "FA", "language": "Farsi", "aliases": ["fa", "farsi", "persian"]},
    {"code": "RU", "language": "Russian", "aliases": ["ru", "russian"]},
    {"code": "CS", "language": "Czech", "aliases": ["cs", "czech"]},
    {"code": "EL", "language": "Greek", "aliases": ["el", "greek"]},
    {"code": "RO", "language": "Romanian", "aliases": ["ro", "romanian"]},
    {"code": "SV", "language": "Swedish", "aliases": ["sv", "swedish"]}
]


def get_justsubtitles_lang(lang_query):
    """ Matches Enigma2 language strings against the provider's supported codes """
    query = str(lang_query).strip().lower()
    for lang_dict in SUPPORTED_LANGUAGES:
        if query in lang_dict["aliases"]:
            return lang_dict
    return None


def parse_rsc_stream(raw_text):
    """
    Robustly extracts the JSON dictionary containing 'subtitles' from Next.js RSC payload.
    """
    for block in re.split(r"(?m)^\d+:", raw_text):
        block = block.strip()
        if not block:
            continue
        if '"subtitles"' in block:
            try:
                data = json.loads(block)
                if isinstance(data, dict) and "subtitles" in data:
                    return data
            except ValueError:
                pass

    start_pos = raw_text.find('{"status":true')
    if start_pos == -1:
        start_pos = raw_text.find('{"status":')

    if start_pos != -1:
        for end_pos in range(len(raw_text), start_pos, -1):
            chunk = raw_text[start_pos:end_pos]
            try:
                data = json.loads(chunk)
                if isinstance(data, dict) and "subtitles" in data:
                    return data
            except ValueError:
                continue

    return None


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    """ Search for movies on JustSubtitles and retrieve the RSC payload """
    print("[JustSubtitles] --- Starting Search ---")

    # JustSubtitles specifically targets the /movie/ endpoint.
    if tvshow:
        print("[JustSubtitles] TV Show search aborted. Provider supports movies only.")
        return [], "", ""

    subtitles = []

    # E741 Fix: Avoid ambiguous variable name 'l'
    requested_langs = [lang for lang in [lang1, lang2, lang3] if lang]
    valid_payloads = []

    for req_lang in requested_langs:
        matched_lang = get_justsubtitles_lang(req_lang)
        if matched_lang:
            payload_tuple = (matched_lang["code"].lower(), matched_lang)
            if payload_tuple not in valid_payloads:
                valid_payloads.append(payload_tuple)

    if not valid_payloads or not title:
        print("[JustSubtitles] Aborting: No valid payloads or missing title.")
        return [], "", ""

    # Clean the title (e.g. convert "The BFG (2016)" -> "The BFG")
    clean_title = re.sub(r'\(\d{4}\)', '', title).strip()
    print("[JustSubtitles] Original title: '{}' | Cleaned title: '{}'".format(
        title, clean_title))

    # Try to extract the year from the title string if it wasn't passed as a parameter
    target_year = str(year) if year and str(year).isdigit() else None
    if not target_year:
        year_match = re.search(r'\((\d{4})\)', title)
        if year_match:
            target_year = year_match.group(1)

    try:
        # 1. Search Query via API
        print("[JustSubtitles] Querying API: {}?q={}".format(
            SEARCH_URL, clean_title))
        res = session.get(SEARCH_URL, params={"q": clean_title}, timeout=10)
        print("[JustSubtitles] API Search HTTP Status: {}".format(res.status_code))

        if res.status_code != 200:
            return [], "", ""

        movies = res.json().get("results", [])
        print("[JustSubtitles] Found {} potential movie matches.".format(len(movies)))
        if not movies:
            return [], "", ""

        # 2. Select Movie Match
        best_match = movies[0]
        if target_year:
            for m in movies:
                m_year = (m.get("release_date") or "")[:4]
                if m_year == target_year:
                    best_match = m
                    break

        tmdb_id = str(best_match.get("id"))
        m_title = best_match.get("title")
        m_year = (best_match.get("release_date") or "")[:4]
        print("[JustSubtitles] Selected Match: {} ({}) | TMDB ID: {}".format(
            m_title, m_year, tmdb_id))

        slug = re.sub(r"[^a-zA-Z0-9]+", "-", m_title).strip("-").lower()
        page_url = "{}/movie/{}/{}-{}".format(BASE_URL, tmdb_id, slug, m_year)
        print("[JustSubtitles] Base Page URL: {}".format(page_url))

        # 3. GET Movie Page (Establish cookies/routing)
        page_res = session.get(page_url, timeout=10)
        print("[JustSubtitles] Page Init HTTP Status: {}".format(
            page_res.status_code))
        if page_res.status_code != 200:
            return [], "", ""

        action_id = "7027f90cea6353aa77261c2f599b2d012419c85e0b"
        router_state_tree = (
            '["", {"children": ["movie", {"children": [["id", "%s", "d"], '
            '{"children": [["slug", "%s-%s", "d"], {"children": ["__PAGE__", {}, null, null]}, '
            'null, null]}, null, null]}, null, null, true]]' % (
                tmdb_id, slug, m_year)
        )

        post_headers = {
            "accept": "text/x-component",
            "content-type": "text/plain;charset=UTF-8",
            "next-action": action_id,
            "next-router-state-tree": router_state_tree,
            "origin": BASE_URL,
            "referer": page_url,
        }

        # 4. Request Subtitles for each chosen language
        for lang_code, lang_payload in valid_payloads:
            # Drop the 'aliases' key so it exactly matches Next.js expectation
            api_lang_dict = {
                "code": lang_payload["code"], "language": lang_payload["language"]}
            payload = [tmdb_id, api_lang_dict, m_year]

            print("[JustSubtitles] Fetching payloads for language: {}".format(
                lang_payload["language"]))

            post_res = session.post(
                page_url,
                data=json.dumps(payload, separators=(",", ":")),
                headers=post_headers,
                timeout=15
            )
            print("[JustSubtitles] POST HTTP Status: {}".format(
                post_res.status_code))

            if post_res.status_code == 200:
                data = parse_rsc_stream(post_res.text)
                if data and data.get("subtitles"):
                    subs_list = data["subtitles"]
                    print("[JustSubtitles] Extracted {} {} subtitles from RSC stream.".format(
                        len(subs_list), lang_payload["language"]))
                    for sub in subs_list:
                        release_name = sub.get("release_name") or sub.get(
                            "name") or "Unknown"
                        author = sub.get("author", "")
                        if author:
                            release_name = "{} (by {})".format(
                                release_name, author)

                        # Simple Sync Check
                        sync = False
                        if file_original_path:
                            base_file = os.path.basename(
                                file_original_path).lower()
                            if base_file.replace(".mkv", "").replace(".mp4", "").replace(".avi", "") in release_name.lower():
                                sync = True

                        relative_url = sub.get("url", "")
                        download_url = "{}{}".format(
                            DL_BASE, relative_url) if not relative_url.startswith("http") else relative_url

                        subtitles.append({
                            "filename": release_name,
                            "sync": sync,
                            "link": download_url,
                            "language_name": lang_payload["language"],
                            "lang": {"2et": lang_code, "name": lang_payload["language"]},
                            "rating": 0
                        })
                else:
                    print("[JustSubtitles] No subtitles block found in RSC stream for {}.".format(
                        lang_payload["language"]))
            else:
                print("[JustSubtitles] Failed to POST for {}.".format(
                    lang_payload["language"]))

    except Exception as e:
        print("[JustSubtitles] Fatal Search Error: {}".format(e))
        import traceback
        traceback.print_exc()

    print("[JustSubtitles] --- Search Finished. Total subtitles: {} ---".format(len(subtitles)))
    return subtitles, "", ""


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """ Stream and save the ZIP archive """
    try:
        subtitle = subtitles_list[pos]
        download_url = subtitle["link"]
        language = subtitle["language_name"]

        print("[JustSubtitles] Starting download from: {}".format(download_url))
        dl_res = session.get(download_url, stream=True, timeout=20)

        if dl_res.status_code != 200:
            print("[JustSubtitles] Download failed with status: {}".format(
                dl_res.status_code))
            return False, "", ""

        if not os.path.exists(tmp_sub_dir):
            try:
                os.makedirs(tmp_sub_dir)
            except OSError:
                pass

        local_tmp_file = zip_subs

        with open(local_tmp_file, "wb") as f:
            for chunk in dl_res.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)

        # Detect file format
        packed = False
        subs_file = ""

        with open(local_tmp_file, "rb") as f:
            header = f.read(2)
            if header.startswith(b'R'):
                packed = True
                subs_file = "rar"
            elif header.startswith(b'P'):
                packed = True
                subs_file = "zip"
            else:
                subs_file = local_tmp_file

        print("[JustSubtitles] Download complete. Packed: {}, Format: {}".format(
            packed, subs_file))
        return packed, language, subs_file

    except Exception as e:
        print("[JustSubtitles] Download error: {}".format(e))
        return False, "", ""
