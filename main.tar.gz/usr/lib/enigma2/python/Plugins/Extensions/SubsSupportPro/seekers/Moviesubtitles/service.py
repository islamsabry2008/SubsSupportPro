# -*- coding: UTF-8 -*-
from __future__ import absolute_import, print_function, division
import os
import re
import warnings
import requests
import six

from ..user_agents import get_session_ua
from ..utilities import log
from .MoviesubtitlesUtilities import get_language_info

# Safely suppress insecure request warnings without causing ImportErrors on strict images
try:
    from urllib3.exceptions import InsecureRequestWarning
    warnings.simplefilter('ignore', InsecureRequestWarning)
except ImportError:
    try:
        from requests.packages.urllib3.exceptions import InsecureRequestWarning
        warnings.simplefilter('ignore', InsecureRequestWarning)
    except ImportError:
        pass


def get_random_ua():
    return get_session_ua("moviesubtitles")


HDR = {'User-Agent': get_random_ua(),
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.',
       'Accept-Language': 'en-US,en;q=0.9,ar-EG;q=0.8,ar;q=0.7',
       'Upgrade-Insecure-Requests': '1',
       'Content-Type': 'application/x-www-form-urlencoded',
       'Host': 'www.moviesubtitles.org',
       'Referer': 'https://www.moviesubtitles.org/search.php',
       'Connection': 'keep-alive',
       'Accept-Encoding': 'gzip, deflate, br, zstd'}

s = requests.Session()

main_url = "http://www.moviesubtitles.org"
debug_pretext = "moviesubtitles.org"


def getSearchTitle(title, year=None):
    title_clean = title.strip()
    print("title_getSearchTitle:", title_clean)

    url = "https://www.moviesubtitles.org/search.php"
    params = {"q": title_clean}
    print("params:", params)

    HDR['User-Agent'] = get_random_ua()

    res = s.post(url, data=params, headers=HDR,
                 verify=False, allow_redirects=True)
    data = six.ensure_str(res.content, encoding='utf-8', errors='ignore')
    data = data.replace("\n", "")

    pattern = r'<a\s+href="(/movie-\d+\.html)">([^<]+)</a>'
    matches = re.findall(pattern, data, re.IGNORECASE)
    print("matches found:", matches)

    for href, link_text in matches:
        if title_clean.lower() in link_text.lower():
            if year is None or str(year) in link_text:
                return 'http://www.moviesubtitles.org' + href

    if matches:
        href, link_text = matches[0]
        print("Fallback match:", href, link_text)
        return 'http://www.moviesubtitles.org' + href

    print("No movie link found")
    return None


def get_rating(downloads):
    rating = int(downloads)
    if (rating < 50):
        rating = 1
    elif (rating >= 50 and rating < 100):
        rating = 2
    elif (rating >= 100 and rating < 150):
        rating = 3
    elif (rating >= 150 and rating < 200):
        rating = 4
    elif (rating >= 200 and rating < 250):
        rating = 5
    elif (rating >= 250 and rating < 300):
        rating = 6
    elif (rating >= 300 and rating < 350):
        rating = 7
    elif (rating >= 350 and rating < 400):
        rating = 8
    elif (rating >= 400 and rating < 450):
        rating = 9
    elif (rating >= 450):
        rating = 10
    return rating


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    languagefound = lang1
    language_info = get_language_info(languagefound)
    language_info1 = language_info['name']
    language_info2 = language_info['2et']

    subtitles_list = []
    msg = ""

    if len(tvshow) == 0 and year:
        searchstring = "%s (%s)" % (title, year)
    elif len(tvshow) > 0 and title == tvshow:
        searchstring = "%s (%02d%02d)" % (tvshow, int(season), int(episode))
    elif len(tvshow) > 0:
        searchstring = "%s S%02dE%02d" % (tvshow, int(season), int(episode))
    else:
        searchstring = title
    log(__name__, "%s Search string = %s" % (debug_pretext, searchstring))
    get_subtitles_list(title, year, language_info2,
                       language_info1, subtitles_list)
    return subtitles_list, "", msg


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    language = subtitles_list[pos]["language_name"]
    filename = subtitles_list[pos]["filename"]
    print(("filename", filename))
    id = subtitles_list[pos]["id"]
    print(("id1", id))
    id = id.replace("subtitle", "download")
    print(("id2", id))
    downloadlink = 'http://www.moviesubtitles.org%s' % (id)
    print(("downloadlink", downloadlink))
    packed = False
    subs_file = None

    if downloadlink:
        log(__name__, "%s Downloadlink: %s " % (debug_pretext, downloadlink))
        viewstate = 0
        previouspage = 0
        subtitleid = 0
        typeid = "zip"
        filmid = 0
        postparams = {'__EVENTTARGET': 's$lc$bcr$downloadLink', '__EVENTARGUMENT': '', '__VIEWSTATE': viewstate,
                      '__PREVIOUSPAGE': previouspage, 'subtitleId': subtitleid, 'typeId': typeid, 'filmId': filmid}
        print(("postparams", postparams))

        HDR['User-Agent'] = get_random_ua()

        response = s.get(downloadlink, data=postparams,
                         headers=HDR, verify=False, allow_redirects=True)
        local_tmp_file = zip_subs
        try:
            log(__name__, "%s Saving subtitles to '%s'" %
                (debug_pretext, local_tmp_file))
            if not os.path.exists(tmp_sub_dir):
                os.makedirs(tmp_sub_dir)
            local_file_handle = open(local_tmp_file, 'wb')
            local_file_handle.write(response.content)
            local_file_handle.close()

            myfile = open(local_tmp_file, "rb")
            myfile.seek(0)
            first_byte = myfile.read(1)
            first_char = six.ensure_str(
                first_byte, encoding='utf-8', errors='ignore') if first_byte else ''

            if (first_char == 'R'):
                typeid = "rar"
                packed = True
                log(__name__, "Discovered RAR Archive")
            else:
                if (first_char == 'P'):
                    typeid = "zip"
                    packed = True
                    log(__name__, "Discovered ZIP Archive")
                else:
                    typeid = "srt"
                    packed = False
                    subs_file = local_tmp_file
                    log(__name__, "Discovered a non-archive file")
            myfile.close()
            log(__name__, "%s Saving to %s" % (debug_pretext, local_tmp_file))
        except Exception as e:
            log(__name__, "%s Failed to save subtitle to %s (%s)" %
                (debug_pretext, local_tmp_file, str(e)))
        if packed:
            subs_file = typeid
        log(__name__, "%s Subtitles saved to '%s'" %
            (debug_pretext, local_tmp_file))
        return packed, language, subs_file


def prepare_search_string(s):
    s = s.strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)
    return s


def get_subtitles_list(title, year, languageshort, languagelong, subtitles_list):
    dst = languageshort.lower()
    title = title.strip()
    search_string = prepare_search_string(title)
    url = getSearchTitle(search_string, year)
    print(("true url", url))

    HDR['User-Agent'] = get_random_ua()

    res = s.get(url, headers=HDR, verify=False, allow_redirects=True)
    content = six.ensure_str(res.content, encoding='utf-8', errors='ignore')

    try:
        log(__name__, "%s Getting '%s' subs ..." %
            (debug_pretext, languageshort))
        pattern = (
            r'<div\s+class="subtitle".*?'
            r'<img\s+[^>]*flags/' + dst + r'\.gif[^>]*>.*?'
            r'<a\s+href="(/subtitle-\d+\.html)"[^>]*>\s*<b>(.*?)</b>.*?'
            r'<span\s+style="[^"]*color\s*:\s*red">(\d+)</span>'
        )
        matches = re.findall(pattern, content, re.IGNORECASE | re.DOTALL)
        print("subtitles", matches)
    except Exception as e:
        log(__name__, "%s Failed to get subtitles: %s" %
            (debug_pretext, str(e)))
        return

    for match in matches:
        try:
            sub_url, filename, downloads = match
            filename = filename.strip()
            print(filename)
            sub_id = sub_url
            print("sub_id", sub_id)
            downloads = re.sub(r"\D", "", downloads)
            try:
                rating = get_rating(downloads)
                print("rating", rating)
            except Exception:
                rating = 0
            log(__name__, "%s Subtitles found: %s (id = %s)" %
                (debug_pretext, filename, sub_id))
            subtitles_list.append({
                'rating': str(rating),
                'no_files': 1,
                'filename': filename,
                'sync': True,
                'id': sub_id,
                'language_flag': languageshort,
                'language_name': languagelong
            })
        except Exception as ex:
            print("Error processing subtitle block:", ex)
            pass
    return
