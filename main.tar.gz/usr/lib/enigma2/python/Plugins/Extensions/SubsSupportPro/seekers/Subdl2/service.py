# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
import os
import re
import requests
import six  # type: ignore
import zipfile
from ..user_agents import get_api_user_agent
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

API_BASE = "https://api.subdl.com"
DL_BASE = "https://dl.subdl.com"
API_TIMEOUT = 10
DOWNLOAD_TIMEOUT = 30

# Languages supported both by SubDL and SubsSupportPro's flag assets
SUBDL_LANGUAGES = {
    "ar": "Arabic",
    "bg": "Bulgarian",
    "bs": "Bosnian",
    "ca": "Catalan",
    "cs": "Czech",
    "da": "Danish",
    "de": "German",
    "el": "Greek",
    "en": "English",
    "es": "Spanish",
    "et": "Estonian",
    "fa": "Persian",
    "fi": "Finnish",
    "fr": "French",
    "fy": "Western Frisian",
    "he": "Hebrew",
    "hi": "Hindi",
    "hr": "Croatian",
    "hu": "Hungarian",
    "id": "Indonesian",
    "is": "Icelandic",
    "it": "Italian",
    "ku": "Kurdish",
    "lt": "Lithuanian",
    "lv": "Latvian",
    "ne": "Nepali",
    "nl": "Dutch",
    "no": "Norwegian",
    "pl": "Polish",
    "pt": "Portuguese",
    "pt-br": "Brazilian Portuguese",
    "ro": "Romanian",
    "ru": "Russian",
    "sk": "Slovak",
    "sl": "Slovenian",
    "sr": "Serbian",
    "sv": "Swedish",
    "th": "Thai",
    "tr": "Turkish",
    "uk": "Ukrainian",
    "vi": "Vietnamese",
    "zh": "Chinese",
}

LANGUAGE_ALIASES = {
    "cz": "cs",
    "ua": "uk",
    "pt_br": "pt-br",
    "pt_pt": "pt",
    "pb": "pt-br",
    "brazilian": "pt-br",
    "nb": "no",
    "nb_no": "no",
    "no_no": "no",
    "farsi": "fa",
    "persian": "fa",
    "zh_cn": "zh",
    "zh_hk": "zh",
    "zh-cn": "zh",
    "zh-tw": "zh",
}


def get_language_info(language_query):
    """Resolve language input by name or code for SubDL API."""
    if not language_query:
        return {"name": "English", "2et": "en"}

    clean_query = str(language_query).strip().lower().replace("_", "-")

    # Map aliases (e.g. 'cz' -> 'cs', 'ua' -> 'uk', 'pt_br' -> 'pt-br')
    target_code = LANGUAGE_ALIASES.get(clean_query, clean_query)

    # 1. Match code directly
    if target_code in SUBDL_LANGUAGES:
        return {"name": SUBDL_LANGUAGES[target_code], "2et": target_code}

    # 2. Match full name
    for code, name in SUBDL_LANGUAGES.items():
        if clean_query == name.lower():
            return {"name": name, "2et": code}

    # Fallback to English if the queried language has no asset representation
    return {"name": "English", "2et": "en"}


def build_headers(api_key):
    return {
        "User-Agent": get_api_user_agent(),
        "Accept": "application/json",
        "Authorization": "Bearer " + str(api_key).strip(),
    }


def _to_text(value):
    if value is None:
        return ""
    try:
        return six.ensure_text(value, errors="replace")
    except Exception:
        try:
            return str(value)
        except Exception:
            return ""


def _clean_filename(filename, fallback="subtitle"):
    name = os.path.basename(_to_text(filename).replace("\\", "/")).strip()
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", name).strip(" ._")
    return name if name else fallback


def _raise_download_error(message):
    raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, message)


def get_subdl2_api():
    try:
        api_key = settings_provider.getSetting("Subdl2_API_KEY")
        if api_key:
            return str(api_key).strip()
    except Exception:
        pass
    print("[Subdl2] Error: SubDL V2 API key is missing.")
    return None


def _get_movie_id(query, media_type, year, api_key):
    """Step 1: Resolve the sd_id via /api/v2/movies/search"""
    clean_query = re.sub(r'\(\d{4}\)', '', query).strip()
    clean_query = re.sub(r'[._+]+', ' ', clean_query).strip()

    params = {
        "q": clean_query,
        "type": media_type,
        "limit": 10,
    }
    try:
        res = requests.get(
            API_BASE + "/api/v2/movies/search",
            params=params,
            headers=build_headers(api_key),
            timeout=API_TIMEOUT,
        )
        if res.status_code == 200:
            results = res.json().get("results", [])
            if results:
                # 1. Match by exact year if available
                if year and str(year).isdigit():
                    for item in results:
                        if str(item.get("year")) == str(year):
                            return item.get("sd_id")

                # 2. Match by exact title if possible
                for item in results:
                    title_name = item.get("name", "").lower()
                    title_orig = item.get("original_name", "").lower()
                    if clean_query.lower() in (title_name, title_orig):
                        return item.get("sd_id")

                # 3. Fallback to first result
                return results[0].get("sd_id")
    except Exception as e:
        print("[Subdl2] Media resolution error: " + str(e))
    return None


def _fetch_subtitles_for_id(sd_id, is_tv, season, episode, languageshort, languagelong, subtitles_list, api_key):
    """Step 2: Fetch and filter subtitles via /api/v2/subtitles/search?sd_id=..."""
    params = {
        "sd_id": sd_id,
        "languages": languageshort,
    }

    s_int = int(season) if season and str(season).isdigit() else None
    e_int = int(episode) if episode and str(episode).isdigit() else None

    # SubDL V2 uses 'season' and 'episode'
    if is_tv:
        if s_int is not None:
            params["season"] = s_int
        if e_int is not None:
            params["episode"] = e_int

    try:
        res = requests.get(
            API_BASE + "/api/v2/subtitles/search",
            params=params,
            headers=build_headers(api_key),
            timeout=API_TIMEOUT,
        )
        if res.status_code != 200:
            return

        data = res.json()
        subtitles = data.get("subtitles", [])

        # Client-side filtering if broad results or season packs return
        if is_tv and s_int is not None and e_int is not None:
            filtered = [
                s for s in subtitles
                if (s.get("season") == s_int and s.get("episode") == e_int)
                or (s.get("season") in (0, None))  # Full-season pack fallback
            ]
            if filtered:
                subtitles = filtered

        for item in subtitles:
            try:
                unpack_files = item.get("unpack_files", [])

                if unpack_files:
                    # If this is a TV pack, extract only the matching episode file
                    target_files = []
                    if is_tv and s_int is not None and e_int is not None:
                        target_files = [
                            f_item for f_item in unpack_files
                            if f_item.get("season") == s_int and f_item.get("episode") == e_int
                        ]

                    if not target_files:
                        target_files = unpack_files

                    for u_file in target_files:
                        rel_name = u_file.get("name") or u_file.get(
                            "release_name") or item.get("release_name") or "subtitle"
                        rel_name = rel_name.replace("::", "_").strip()
                        rel_url = u_file.get("url")

                        # Append clean S/E tag for display ONLY if it is a TV Show
                        if is_tv:
                            f_season = u_file.get("season", item.get("season"))
                            f_ep = u_file.get("episode", item.get("episode"))
                            if f_season is not None and f_ep is not None and (f_season > 0 or f_ep > 0):
                                if ("S%02d" % f_season) not in rel_name.upper():
                                    rel_name = "S%02dE%02d - %s" % (
                                        f_season, f_ep, rel_name)

                        if rel_url:
                            subtitles_list.append({
                                'filename': rel_name,
                                'sync': True,
                                'id': rel_url,
                                'language_flag': languageshort,
                                'language_name': languagelong,
                            })
                else:
                    rel_name = item.get("release_name") or item.get(
                        "name") or "subtitle"
                    rel_name = rel_name.replace("::", "_").strip()
                    rel_url = item.get("url")

                    # Append clean S/E tag for display ONLY if it is a TV Show
                    if is_tv:
                        f_season = item.get("season")
                        f_ep = item.get("episode")
                        if f_season is not None and f_ep is not None and (f_season > 0 or f_ep > 0):
                            if ("S%02d" % f_season) not in rel_name.upper():
                                rel_name = "S%02dE%02d - %s" % (f_season,
                                                                f_ep, rel_name)

                    if rel_url:
                        subtitles_list.append({
                            'filename': rel_name,
                            'sync': True,
                            'id': rel_url,
                            'language_flag': languageshort,
                            'language_name': languagelong,
                        })
            except Exception as item_err:
                print("[Subdl2] Error parsing sub item: " + str(item_err))
    except Exception as search_err:
        print("[Subdl2] Subtitle search error: " + str(search_err))


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""

    api_key = get_subdl2_api()
    if not api_key:
        return subtitles_list, "", "SubDL V2 requires an API Key"

    language_info = get_language_info(lang1)
    if not language_info:
        return subtitles_list, "", msg

    lang_long = language_info['name']
    lang_short = language_info['2et']

    is_tv = bool(tvshow) or bool(season and episode)
    media_type = "tv" if is_tv else "movie"
    search_query = tvshow if tvshow else title

    if not search_query and file_original_path:
        filename = os.path.basename(file_original_path)
        match_obj = re.match(
            r'^(.*?)(?:\.\d{4}|\.S\d{2}E\d{2}|\.\d{3,4}p|\.\w{2,3})?\.\w+$', filename)
        if match_obj:
            search_query = match_obj.group(1).replace('.', ' ').strip()

    if not search_query:
        return subtitles_list, "", msg

    sd_id = _get_movie_id(search_query, media_type, year, api_key)

    if not sd_id and is_tv and title and title != tvshow:
        sd_id = _get_movie_id(title, "tv", year, api_key)

    if sd_id:
        _fetch_subtitles_for_id(
            sd_id, is_tv, season, episode, lang_short, lang_long, subtitles_list, api_key)

    return subtitles_list, "", msg


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_info = subtitles_list[pos]
    relative_url = _to_text(subtitle_info["id"]).strip()
    language = subtitle_info["language_name"]

    if not os.path.exists(tmp_sub_dir):
        os.makedirs(tmp_sub_dir)

    api_key = get_subdl2_api()
    headers = build_headers(api_key) if api_key else {}

    clean_rel = relative_url if relative_url.startswith(
        "/") else "/" + relative_url

    download_urls = [
        DL_BASE + clean_rel,
        API_BASE + clean_rel,
    ]

    response = None
    for url in download_urls:
        try:
            res = requests.get(url, headers=headers,
                               timeout=DOWNLOAD_TIMEOUT, allow_redirects=True)
            if res.status_code == 200 and len(res.content) > 0:
                response = res
                break
        except Exception:
            pass

    if response is None:
        _raise_download_error(
            "Failed to download subtitle from SubDL CDN endpoints.")

    safe_name = _clean_filename(
        subtitle_info.get("filename", "subdl_subtitle"))
    local_file = os.path.join(tmp_sub_dir, safe_name)

    with open(local_file, "wb") as file_out:
        file_out.write(response.content)

    # Inspect file header (ZIP / RAR vs raw text)
    try:
        with open(local_file, "rb") as file_in:
            magic = file_in.read(4)

        if magic.startswith(b'PK'):
            with zipfile.ZipFile(local_file, 'r') as zf:
                for name in zf.namelist():
                    if name.endswith('/'):
                        continue
                    ext = os.path.splitext(name)[1].lower()
                    if ext in ['.srt', '.sub', '.ass']:
                        safe_extracted = _clean_filename(name)
                        out_path = os.path.join(tmp_sub_dir, safe_extracted)
                        with open(out_path, "wb") as out_f:
                            out_f.write(zf.read(name))
                        return False, language, out_path
            return True, language, local_file

        if magic.startswith(b'Rar!'):
            return True, language, local_file
    except Exception as e:
        print("[Subdl2] Header inspection error: " + str(e))

    # Single unpacked subtitle file (.srt)
    return False, language, local_file
