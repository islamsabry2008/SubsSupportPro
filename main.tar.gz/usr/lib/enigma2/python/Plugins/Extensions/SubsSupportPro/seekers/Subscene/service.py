# -*- coding: utf-8 -*-
import os
import re
import requests
import zipfile
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from .SubsceneUtilities import get_language_info
from ..user_agents import get_random_ua
from ..seeker import SubtitlesDownloadError, SubtitlesErrors
import warnings

# Suppress harmless BeautifulSoup and InsecureRequest warnings on older Enigma2 images
warnings.filterwarnings(
    'ignore', message='.*soupsieve.*', category=UserWarning)
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

BASE_URL = "https://sub-scene.com"
TIMEOUT = 15

SEASONS_TEXT = [
    "Specials", "First", "Second", "Third", "Fourth", "Fifth", "Sixth",
    "Seventh", "Eighth", "Ninth", "Tenth", "Eleventh", "Twelfth",
    "Thirteenth", "Fourteenth", "Fifteenth", "Sixteenth", "Seventeenth",
    "Eighteenth", "Nineteenth", "Twentieth", "Twenty-first", "Twenty-second",
    "Twenty-third", "Twenty-fourth", "Twenty-fifth"
]


def get_headers():
    return {
        "User-Agent": get_random_ua(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1"
    }


def build_episode_pattern(ep_num):
    if not ep_num:
        return None
    ep = int(ep_num)
    patterns = [
        r"s\d+[\.\s_-]*e0*%d\b" % ep,
        r"\b\d+x0*%d\b" % ep,
        r"\b(?:ep|episode)[\.\s_-]*0*%d\b" % ep,
        r"\be0*%d\b" % ep,
    ]
    return re.compile("|".join(patterns), re.IGNORECASE)


def _clean_filename(filename, fallback="subtitle"):
    name = os.path.basename(filename.replace("\\", "/")).strip()
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", name).strip(" ._")
    name = name.replace("::", "_")
    return name if name else fallback


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""

    # Map requested languages
    requested_langs = []
    for l in [lang1, lang2, lang3]:
        info = get_language_info(l)
        if info and info.get('name'):
            requested_langs.append(
                (info['name'].lower(), info['name'], info['2et']))

    if not requested_langs:
        return subtitles_list, "", msg

    search_query = tvshow if tvshow else title
    if not search_query and file_original_path:
        filename = os.path.basename(file_original_path)
        m = re.match(
            r'^(.*?)(?:\.\d{4}|\.S\d{2}E\d{2}|\.\d{3,4}p|\.\w{2,3})?\.\w+$', filename)
        if m:
            search_query = m.group(1).replace('.', ' ').strip()

    if not search_query:
        return subtitles_list, "", msg

    # 1. Query the suggest API
    url = "%s/suggest?query=%s" % (BASE_URL, quote_plus(search_query))
    try:
        res = requests.get(url, headers=get_headers(),
                           timeout=TIMEOUT, verify=False)
        if res.status_code != 200:
            return subtitles_list, "", "Subscene API failed"
        data = res.json()
    except Exception as e:
        print("[Subscene] Search failed: " + str(e))
        return subtitles_list, "", str(e)

    is_tv = bool(tvshow) or bool(season and episode)
    media_key = "tv" if is_tv else "film"
    items = data.get(media_key, [])

    # Fallback if mistagged
    if not items:
        fallback_key = "film" if is_tv else "tv"
        items = data.get(fallback_key, [])

    if not items:
        return subtitles_list, "", msg

    # 2. Resolve Exact Movie/Show ID with Season Mapping
    selected_id = None

    if is_tv and season and str(season).isdigit():
        s_idx = int(season)
        s_text = SEASONS_TEXT[s_idx].lower(
        ) if s_idx < len(SEASONS_TEXT) else ""
        for item in items:
            title_lower = item.get("name", "").lower()
            if s_text and ("%s season" % s_text) in title_lower:
                selected_id = item.get("id")
                break
            elif ("season %d" % s_idx) in title_lower:
                selected_id = item.get("id")
                break

    if not selected_id and year and str(year).isdigit():
        for item in items:
            if str(item.get("year")) == str(year):
                selected_id = item.get("id")
                break

    if not selected_id:
        clean_q = search_query.lower().strip()
        for item in items:
            if item.get("name", "").lower() == clean_q:
                selected_id = item.get("id")
                break

    if not selected_id:
        selected_id = items[0].get("id")

    # 3. Parse Subtitle Listings
    list_url = "%s/subscene/%s" % (BASE_URL, selected_id)
    try:
        resp = requests.get(list_url, headers=get_headers(),
                            timeout=TIMEOUT, verify=False)
        if resp.status_code != 200:
            return subtitles_list, "", "Failed to load subtitle list"

        soup = BeautifulSoup(resp.text, "html.parser")
        ep_regex = build_episode_pattern(episode) if is_tv else None

        for a_tag in soup.find_all("a", href=True):
            href = a_tag["href"]
            if "/subtitle/" in href and not href.endswith("/ratings"):
                text = a_tag.get_text(separator=" ", strip=True)
                text_lower = text.lower()

                # --- MULTI-PART / TRUNCATED SUBTITLE FILTER ---
                if text.strip().endswith('..'):
                    continue

                # Safely use re.IGNORECASE parameter instead of inline (?i) flags
                is_multipart = re.search(
                    r'(?:\b|_)(?:cd|part|pt|disc|disk)[\s_.-]*[1-9](?:\b|$)', text, flags=re.IGNORECASE)
                if is_multipart:
                    if not re.search(r'(?:\b|_)(?:cd|part|pt|disc|disk)[\s_.-]*[1-9](?:\b|$)', search_query, flags=re.IGNORECASE):
                        continue
                # -----------------------------------------------

                # Filter by Language
                matched_lang = None
                for l_lower, l_long, l_short in requested_langs:
                    if l_lower in text_lower:
                        matched_lang = (l_long, l_short)
                        break

                if not matched_lang:
                    continue

                # Filter by Episode Pattern (if TV Show)
                if ep_regex and not ep_regex.search(text):
                    continue

                full_link = BASE_URL + href if href.startswith("/") else href

                # --- STRIP LANGUAGE NAME FROM START OF FILENAME SAFELY ---
                text = re.sub(
                    r'^' + re.escape(matched_lang[0]) + r'\s*', '', text, flags=re.IGNORECASE)

                filename = _clean_filename(text)

                # Check simple sync status based on release name
                sync = False
                if file_original_path:
                    base_file = os.path.basename(file_original_path).lower()
                    if base_file.replace(".mkv", "").replace(".mp4", "").replace(".avi", "") in text_lower:
                        sync = True

                subtitles_list.append({
                    'filename': filename,
                    'sync': sync,
                    'link': full_link,
                    'language_name': matched_lang[0],
                    'language_flag': matched_lang[1],
                })

    except Exception as e:
        print("[Subscene] Subtitle fetch failed: " + str(e))

    return subtitles_list, "", msg


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    sub_info = subtitles_list[pos]
    page_url = sub_info["link"]
    language = sub_info["language_name"]

    if not os.path.exists(tmp_sub_dir):
        os.makedirs(tmp_sub_dir)

    # 1. Scrape the true download link from the subtitle page
    try:
        resp = requests.get(page_url, headers=get_headers(),
                            timeout=TIMEOUT, verify=False)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")
        download_div = soup.find("div", class_="download")
        if not download_div:
            raise SubtitlesDownloadError(
                SubtitlesErrors.UNKNOWN_ERROR, "Download button not found")

        dl_link = download_div.find("a", class_="button", href=True)
        if not dl_link:
            raise SubtitlesDownloadError(
                SubtitlesErrors.UNKNOWN_ERROR, "Download href not found")

        href = dl_link["href"]
        download_url = BASE_URL + href if href.startswith("/") else href
    except Exception as e:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, str(e))

    # 2. Download the ZIP file
    local_tmp_file = os.path.join(
        tmp_sub_dir, _clean_filename(sub_info["filename"] + ".zip"))

    try:
        dl_res = requests.get(
            download_url, headers=get_headers(), timeout=20, verify=False)
        dl_res.raise_for_status()

        with open(local_tmp_file, "wb") as f:
            f.write(dl_res.content)
    except Exception as e:
        raise SubtitlesDownloadError(
            SubtitlesErrors.UNKNOWN_ERROR, "File download failed: " + str(e))

    # 3. Smart Internal Unpacking
    packed = False
    subs_file = local_tmp_file

    try:
        with open(local_tmp_file, "rb") as f:
            magic = f.read(4)

        if magic.startswith(b'Rar!'):
            packed = True
            subs_file = local_tmp_file
        elif magic.startswith(b'PK'):
            try:
                with zipfile.ZipFile(local_tmp_file, 'r') as zf:
                    for name in zf.namelist():
                        if name.endswith('/'):
                            continue

                        ext = os.path.splitext(name)[1].lower()
                        if ext in ['.srt', '.sub', '.ass']:
                            safe_name = _clean_filename(name)
                            out_path = os.path.join(tmp_sub_dir, safe_name)
                            with open(out_path, "wb") as out_f:
                                out_f.write(zf.read(name))

                            return False, language, out_path
            except Exception as e:
                print("[Subscene] Internal Unzip Error:", e)

            # Fallback if internal extraction fails
            packed = True
            subs_file = local_tmp_file

    except Exception as e:
        print("[Subscene] Header inspection error:", e)

    return packed, language, subs_file
