# -*- coding: utf-8 -*-
'''
Created on Feb 10, 2014

@author: marko
'''
from __future__ import absolute_import
try:
    from . import _
except ImportError:
    def _(txt):
        return txt

from .seeker import SubtitlesDownloadError, SubtitlesSearchError, SubtitlesErrors

try:
    from .xbmc_subtitles import (
        LocalDriveSeeker,
        SubsourceSeeker,
        Subf2mSeeker,
        SubdlSeeker,
        Subdl2Seeker,  # <--- Added Subdl V2
        SubsceneSeeker,
        JustsubtitlesSeeker,
        YtssubsSeeker,
        MoviesubtitlesSeeker,
        OpenSubtitles2Seeker,
        SubtitlesmoraSeeker,
        WyzieSeeker,
        NovalermoraSeeker,
    )
except (ValueError, ImportError):
    try:
        from xbmc_subtitles import (
            LocalDriveSeeker,
            SubsourceSeeker,
            Subf2mSeeker,
            SubdlSeeker,
            Subdl2Seeker,
            SubsceneSeeker,
            JustsubtitlesSeeker,
            YtssubsSeeker,
            MoviesubtitlesSeeker,
            OpenSubtitles2Seeker,
            SubtitlesmoraSeeker,
            WyzieSeeker,
            NovalermoraSeeker,
        )
    except (ValueError, ImportError):
        LocalDriveSeeker = None
        SubsourceSeeker = None
        Subf2mSeeker = None
        SubdlSeeker = None
        Subdl2Seeker = None
        SubsceneSeeker = None
        JustsubtitlesSeeker = None
        YtssubsSeeker = None
        MoviesubtitlesSeeker = None
        OpenSubtitles2Seeker = None
        SubtitlesmoraSeeker = None
        WyzieSeeker = None
        NovalermoraSeeker = None

__all__ = [
    'SubtitlesDownloadError',
    'SubtitlesSearchError',
    'SubtitlesErrors',
    'LocalDriveSeeker',
    'SubsourceSeeker',
    'Subf2mSeeker',
    'SubdlSeeker',
    'Subdl2Seeker',
    'SubsceneSeeker',
    'JustsubtitlesSeeker',
    'YtssubsSeeker',
    'MoviesubtitlesSeeker',
    'OpenSubtitles2Seeker',
    'SubtitlesmoraSeeker',
    'WyzieSeeker',
    'NovalermoraSeeker',
]
