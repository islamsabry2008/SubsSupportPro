# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function

import io
import os
import re
import shutil

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigYesNo, ConfigSelection, getConfigListEntry
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.ChoiceBox import ChoiceBox
from Tools.Directories import fileExists
from Tools.LoadPixmap import LoadPixmap
from enigma import (  # type: ignore
    eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT,
    RT_VALIGN_CENTER, gFont
)

from .. import _
from ..compat import MessageBox
from ..utils import toString, toUnicode
from ..e2_utils import (
    is4K, is2K, isFullHD, is_dreamos_image, get_image_distro,
    _apply_subssupportpro_theme, _apply_subssupportpro_version,
    _apply_scrollbar_attributes, _sanitize_skin_for_dreamos
)

# =========================================================================
# PATHS & RESOLUTION HELPERS
# =========================================================================

SUBSPRO_IMG_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "img"
)


def _get_res_info():
    """Return (scale_from_fhd, short_label, full_label) for HD/FHD/2K/4K."""
    if is4K():
        return 2.0, "4K", "4K (3840x2160)"
    if is2K():
        return 4.0 / 3.0, "2K", "2K/WQHD (2560x1440)"
    if isFullHD():
        return 1.0, "FHD", "FHD (1920x1080)"
    return 2.0 / 3.0, "HD", "HD (1280x720)"


def _sc(val, scale):
    return int(round(val * scale))


def _prepare_skin(raw_skin):
    """Apply SubsSupportPro theme, version, scrollbar and DreamOS sanitizer."""
    skin = _apply_subssupportpro_theme(raw_skin)
    skin = _apply_subssupportpro_version(skin)
    skin = _apply_scrollbar_attributes(skin)
    skin = _sanitize_skin_for_dreamos(skin)
    return skin


def _build_color_button_xml(name, x, y, circle_d, label_w, font_sz, color, scale):
    """Build a SubsSupportPro-style circular colored button + label."""
    rad = circle_d // 2
    sh_d = circle_d + max(2, _sc(2, scale))
    sh_rad = sh_d // 2
    lbl_x = x + circle_d + _sc(10, scale)
    return (
        '  <eLabel name="" position="{x},{y}" size="{sh_d},{sh_d}" cornerRadius="{sh_rad}" backgroundColor="#999999" zPosition="-1" />\n'
        '  <eLabel name="" position="{x},{y}" size="{d},{d}" cornerRadius="{rad}" backgroundColor="{col}" />\n'
        '  <widget name="{name}" position="{lx},{y}" size="{lw},{d}" valign="center" halign="left" zPosition="2" font="Regular;{fs}" transparent="1" foregroundColor="white" backgroundColor="{col}" />\n'
    ).format(
        x=x, y=y, d=circle_d, rad=rad, sh_d=sh_d, sh_rad=sh_rad,
        col=color, name=name, lx=lbl_x, lw=label_w, fs=font_sz
    )


def _build_pill_badge_xml(text, x, y, pill_w, pill_h, font_sz, scale):
    """Build a SubsSupportPro-style purple INFO/MENU pill badge."""
    rad = pill_h // 2
    sh_w = pill_w + max(2, _sc(2, scale))
    sh_h = pill_h + max(2, _sc(2, scale))
    sh_rad = sh_h // 2
    return (
        '  <eLabel name="" position="{x},{y}" size="{sh_w},{sh_h}" cornerRadius="{sh_rad}" backgroundColor="#999999" zPosition="-1" />\n'
        '  <eLabel name="" position="{x},{y}" size="{w},{h}" cornerRadius="{rad}" backgroundColor="#5d37d9" text="{txt}" font="Regular;{fs}" halign="center" valign="center" foregroundColor="white" zPosition="2" />\n'
    ).format(
        x=x, y=y, w=pill_w, h=pill_h, rad=rad,
        sh_w=sh_w, sh_h=sh_h, sh_rad=sh_rad, txt=text, fs=font_sz
    )


def _get_image_display_name():
    try:
        distro = get_image_distro() or "Enigma2"
        if is_dreamos_image() and "dream" not in distro and "vti" not in distro:
            return "DreamOS ({})".format(distro)
        return distro.upper() if len(distro) <= 4 else distro.capitalize()
    except Exception:
        return "Enigma2"


# =========================================================================
# CORE LOGIC: ARABIC CLEANING & SUBTITLE MODIFICATIONS (PY2 + PY3 SAFE)
# =========================================================================

ARABIC_RANGE = re.compile(
    u'[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff\ufb50-\ufdff\ufe70-\ufeff]'
)
BIDI_CHARS = re.compile(
    u'[\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff\u200b\u200c\u200d\u00a0]'
)
TASHKEEL = re.compile(u'[\u064b-\u0652\u0670]')
TATWEEL = re.compile(u'\u0640')

# Strange symbols at the beginning of an Arabic line
NOISE_START = re.compile(
    u'^[\\s\\-_~*#^=+<>|\\\\/\xab\xbb\u201c"\'\u201e\u2019\u2018@%$&;:,\\.\\?\u061f!\\)\\]\\}]+'
)
# Strange symbols at the end of an Arabic line
NOISE_END_SYMBOLS = re.compile(
    u'[\\s\\-_~*#^=+<>|\\\\/\xab\xbb\u201c"\'\u201e\u2019\u2018@%$&;:\\(\\[\\{]+$'
)

AD_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        u'opensubtitles', u'subscene', u'addic7ed', u'yify', u'podnapisi',
        u'www\\.[a-z0-9\\-]+\\.[a-z]{2,}', u'https?://[^\\s]+',
        u'\u062a\u0631\u062c\u0645\u0629\\s*:',
        u'\u062a\u0639\u062f\u064a\u0644\\s*:',
        u'\u062a\u0632\u0627\u0645\u0646\\s*:',
        u'\u0642\u0627\u0645 \u0628\u0627\u0644\u062a\u0631\u062c\u0645\u0629',
        u'\u0645\u0648\u0642\u0639\\s*:'
    ]
]

TIMECODE_RE = re.compile(
    u'(\\d{1,2}:\\d{2}:\\d{2}[,\\.]\\d{1,3})\\s*-->\\s*(\\d{1,2}:\\d{2}:\\d{2}[,\\.]\\d{1,3})'
)
DIALOGUE_DASH_RE = re.compile(u'^\\s*[-\u2013\u2014]\\s*')
HI_NOTES_RE = re.compile(u'[\u266a\u266b#\u266c]+')
SPEAKER_AR_RE = re.compile(u'^[\u0600-\u06ff\\s]{2,15}:\\s*')
SPEAKER_LATIN_RE = re.compile(u'^[A-Za-z0-9_\\s]{2,15}:\\s*')


def clean_arabic_line(line, remove_tashkeel=False, remove_tatweel=True, preserve_dialogue_dash=True):
    """
    Cleans an Arabic line:
    - Strips invisible BiDi direction marks and BOM
    - Removes strange symbols at beginning and end of lines
    - Restores clean dialogue dash
    - Normalizes punctuation and removes Tashkeel/Tatweel if chosen
    """
    line = toUnicode(line)
    if not line:
        return u""
    if not ARABIC_RANGE.search(line):
        return line.strip()

    # 1. Strip invisible BiDi and control characters
    text = BIDI_CHARS.sub(u'', line)

    # 2. Tashkeel / Tatweel
    if remove_tashkeel:
        text = TASHKEEL.sub(u'', text)
    if remove_tatweel:
        text = TATWEEL.sub(u'', text)

    # 3. Check if line starts with dialogue dash
    has_dash = bool(DIALOGUE_DASH_RE.match(text))

    # 4. Remove strange symbols from beginning and end
    text = NOISE_START.sub(u'', text)
    text = NOISE_END_SYMBOLS.sub(u'', text)

    # 5. Normalize repeated trailing punctuation (? or !)
    text = re.sub(u'[\\?\u061f]{2,}', u'\u061f', text)
    text = re.sub(u'!{2,}', u'!', text)
    text = re.sub(u'\\.{4,}', u'...', text)

    # 6. Restore single clean dialogue dash if line had one
    if preserve_dialogue_dash and has_dash and text:
        text = u"- " + text

    # 7. Normalize spaces
    text = re.sub(u'[ \t]+', u' ', text)
    return text.strip()


def time_to_ms(time_str):
    try:
        parts = toUnicode(time_str).split(u':')
        h = int(parts[0])
        m = int(parts[1])
        s_ms = parts[2].replace(u'.', u',').split(u',')
        s = int(s_ms[0])
        ms = int(s_ms[1]) if len(s_ms) > 1 else 0
        return (h * 3600000) + (m * 60000) + (s * 1000) + ms
    except Exception:
        return 0


def ms_to_time(ms):
    if ms < 0:
        ms = 0
    h = int(ms) // 3600000
    ms = int(ms) % 3600000
    m = ms // 60000
    ms %= 60000
    s = ms // 1000
    ms %= 1000
    return u"{:02d}:{:02d}:{:02d},{:03d}".format(h, m, s, ms)


def shift_timecode(time_string, offset_ms):
    """Adds or subtracts milliseconds from a subtitle time string."""
    try:
        start_str, end_str = toUnicode(time_string).split(u' --> ')
        start_ms = time_to_ms(start_str) + offset_ms
        end_ms = time_to_ms(end_str) + offset_ms
        return u"{} --> {}".format(ms_to_time(start_ms), ms_to_time(end_ms))
    except Exception:
        return toUnicode(time_string)


def convert_time_fps(time_string, old_fps, new_fps):
    """Converts a subtitle timecode from old_fps to new_fps."""
    try:
        ratio = float(old_fps) / float(new_fps)
        start_str, end_str = toUnicode(time_string).split(u' --> ')
        start_ms = int(time_to_ms(start_str) * ratio)
        end_ms = int(time_to_ms(end_str) * ratio)
        return u"{} --> {}".format(ms_to_time(start_ms), ms_to_time(end_ms))
    except Exception:
        return toUnicode(time_string)


def parse_srt(filepath, force_encoding=None):
    """Parses an SRT file with intelligent encoding auto-detection and robust stream parsing."""
    if not fileExists(filepath):
        return [], "file_not_found"

    raw_bytes = b""
    try:
        with open(filepath, 'rb') as f:
            raw_bytes = f.read()
    except Exception as e:
        print("[SubsSupportPro][SrtEditor] Read failed:", e)
        return [], "read_error"

    if not raw_bytes:
        return [], "empty_file"

    encodings_to_try = [force_encoding] if force_encoding else [
        'utf-8-sig', 'utf-8', 'cp1256', 'iso-8859-6', 'cp1252', 'latin-1'
    ]

    content = u""
    detected_encoding = "utf-8"
    for enc in encodings_to_try:
        if not enc:
            continue
        try:
            content = raw_bytes.decode(enc)
            detected_encoding = enc
            break
        except Exception:
            continue

    if not content and not force_encoding:
        content = raw_bytes.decode('latin-1', 'replace')
        detected_encoding = "latin-1 (fallback)"

    lines = content.replace(u'\r\n', u'\n').replace(u'\r', u'\n').split(u'\n')
    subs = []
    curr_sub = None

    for raw_line in lines:
        line = raw_line.strip()
        m = TIMECODE_RE.search(line)
        if m:
            t_start = m.group(1).replace(u'.', u',')
            t_end = m.group(2).replace(u'.', u',')
            if len(t_start.split(u':')[0]) == 1:
                t_start = u"0" + t_start
            if len(t_end.split(u':')[0]) == 1:
                t_end = u"0" + t_end

            if curr_sub and curr_sub['text']:
                t_lines = curr_sub['text'].split(u'\n')
                if t_lines[-1].strip().isdigit():
                    t_lines.pop()
                    curr_sub['text'] = u'\n'.join(t_lines).strip()

            curr_sub = {
                'index': u"{}".format(len(subs) + 1),
                'time': u"{} --> {}".format(t_start, t_end),
                'text': u''
            }
            subs.append(curr_sub)
        elif curr_sub is not None:
            if curr_sub['text']:
                curr_sub['text'] += u'\n' + line
            else:
                curr_sub['text'] = line

    if curr_sub and curr_sub['text']:
        t_lines = curr_sub['text'].split(u'\n')
        if t_lines[-1].strip().isdigit():
            t_lines.pop()
            curr_sub['text'] = u'\n'.join(t_lines).strip()

    for s in subs:
        s['text'] = s['text'].strip()

    return subs, detected_encoding


def create_backup(filepath):
    """Creates a .bak backup before modifying."""
    try:
        if fileExists(filepath):
            backup_path = filepath + ".bak"
            shutil.copy2(filepath, backup_path)
            return backup_path
    except Exception as e:
        print("[SubsSupportPro][SrtEditor] Backup failed:", e)
    return None


def restore_backup(filepath):
    """Restores the .bak backup if it exists."""
    backup_path = filepath + ".bak"
    try:
        if fileExists(backup_path):
            shutil.copy2(backup_path, filepath)
            return True
    except Exception as e:
        print("[SubsSupportPro][SrtEditor] Restore failed:", e)
    return False


def save_srt(filepath, subs, encoding='utf-8', backup=True):
    """Saves subtitle list to SRT format (Py2 & Py3 safe), optionally creating a backup first."""
    try:
        if backup:
            create_backup(filepath)

        with io.open(filepath, 'w', encoding=encoding, errors='replace') as f:
            for idx, sub in enumerate(subs, 1):
                f.write(u"{}\n{}\n{}\n\n".format(
                    idx, toUnicode(sub['time']), toUnicode(sub['text'])
                ))
        return True
    except Exception as e:
        print("[SubsSupportPro][SrtEditor] Save failed:", e)
        return False


def modify_subtitles(subs, options):
    """Applies comprehensive batch modifications to the subtitles."""
    stats = {
        'cleaned_arabic': 0,
        'removed_tags': 0,
        'removed_hi': 0,
        'removed_speakers': 0,
        'removed_ads': 0,
        'removed_empty': 0,
        'overlapping_fixed': 0,
        'time_shifted': bool(options.get('shift_ms', 0) != 0),
        'fps_converted': bool(options.get('fps_ratio', 1.0) != 1.0)
    }

    shift_ms = options.get('shift_ms', 0)
    fps_ratio = options.get('fps_ratio', 1.0)
    new_subs = []

    for sub in subs:
        timecode = toUnicode(sub['time'])

        if fps_ratio != 1.0:
            try:
                start_str, end_str = timecode.split(u' --> ')
                start_ms = int(time_to_ms(start_str) * fps_ratio)
                end_ms = int(time_to_ms(end_str) * fps_ratio)
                timecode = u"{} --> {}".format(ms_to_time(start_ms), ms_to_time(end_ms))
            except Exception:
                pass

        if shift_ms != 0:
            timecode = shift_timecode(timecode, shift_ms)

        lines = toUnicode(sub['text']).split(u'\n')
        new_lines = []
        is_ad = False

        for line in lines:
            orig_line = line

            if options.get('remove_ads', True):
                if any(p.search(line) for p in AD_PATTERNS):
                    stats['removed_ads'] += 1
                    is_ad = True
                    break

            if options.get('remove_html', True):
                if u'<' in line and u'>' in line:
                    line_no_html = re.sub(u'<[^>]+>', u'', line)
                    if line_no_html != line:
                        stats['removed_tags'] += 1
                        line = line_no_html

            if options.get('remove_ass', True):
                if u'{' in line and u'}' in line:
                    line_no_ass = re.sub(u'\\{[^\\}]+\\}', u'', line)
                    if line_no_ass != line:
                        stats['removed_tags'] += 1
                        line = line_no_ass

            if options.get('remove_hi', True):
                line_no_hi = re.sub(u'\\[[^\\]]+\\]', u'', line)
                line_no_hi = re.sub(u'\\([^\\)]+\\)', u'', line_no_hi)
                line_no_hi = HI_NOTES_RE.sub(u'', line_no_hi)
                if line_no_hi != line:
                    stats['removed_hi'] += 1
                    line = line_no_hi

            if options.get('remove_speakers', False):
                line_no_spk = SPEAKER_LATIN_RE.sub(u'', line)
                line_no_spk = SPEAKER_AR_RE.sub(u'', line_no_spk)
                if line_no_spk != line:
                    stats['removed_speakers'] += 1
                    line = line_no_spk

            if options.get('clean_arabic', True):
                if ARABIC_RANGE.search(line):
                    cleaned = clean_arabic_line(
                        line,
                        remove_tashkeel=options.get('remove_tashkeel', False),
                        remove_tatweel=options.get('remove_tatweel', True),
                        preserve_dialogue_dash=True
                    )
                    if cleaned != orig_line:
                        stats['cleaned_arabic'] += 1
                    line = cleaned

            line = line.strip()
            if line:
                new_lines.append(line)

        if is_ad:
            continue

        final_text = u'\n'.join(new_lines).strip()
        if not final_text:
            stats['removed_empty'] += 1
            continue

        new_subs.append({
            'index': u"{}".format(len(new_subs) + 1),
            'time': timecode,
            'text': final_text
        })

    if options.get('fix_overlaps', True) and len(new_subs) > 1:
        for i in range(len(new_subs) - 1):
            try:
                curr_start, curr_end = new_subs[i]['time'].split(u' --> ')
                next_start, _next_end = new_subs[i + 1]['time'].split(u' --> ')
                curr_end_ms = time_to_ms(curr_end)
                next_start_ms = time_to_ms(next_start)

                if curr_end_ms > next_start_ms:
                    adjusted_end_ms = max(time_to_ms(curr_start), next_start_ms - 50)
                    new_subs[i]['time'] = u"{} --> {}".format(
                        curr_start, ms_to_time(adjusted_end_ms)
                    )
                    stats['overlapping_fixed'] += 1
            except Exception:
                pass

    return new_subs, stats


def build_srt_entry(sub, scale, item_h):
    """Constructs MultiContent list entry with Arabic RTL support & resolution scaling."""
    clean_text = toUnicode(sub['text']).replace(u'\n', u'  ')
    is_arabic = bool(ARABIC_RANGE.search(clean_text))
    align_flag = (RT_HALIGN_RIGHT if is_arabic else RT_HALIGN_LEFT) | RT_VALIGN_CENTER

    idx_x = _sc(16, scale)
    idx_w = _sc(84, scale)
    time_x = _sc(110, scale)
    time_w = _sc(390, scale)
    txt_x = _sc(515, scale)
    txt_w = _sc(1080, scale)

    return [
        sub,
        MultiContentEntryText(
            pos=(idx_x, 0), size=(idx_w, item_h), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=toString(sub['index'])
        ),
        MultiContentEntryText(
            pos=(time_x, 0), size=(time_w, item_h), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=toString(sub['time'])
        ),
        MultiContentEntryText(
            pos=(txt_x, 0), size=(txt_w, item_h), font=1,
            flags=align_flag, text=toString(clean_text)
        )
    ]


# =========================================================================
# CUSTOM SRT FILE LIST COMPONENT (USES SUBSSUPPORTPRO IMG ASSETS)
# =========================================================================

class SrtFileList(MenuList):
    """Custom file list using SubsSupportPro directory/subtitles icons (Py2/Py3 & DreamOS safe)."""

    def __init__(self, directory, scale=1.0):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        self.scale = scale
        self.item_height = _sc(50, scale)
        font_sz = _sc(26, scale)
        self.font = gFont("Regular", font_sz)
        self.l.setFont(0, self.font)
        self.l.setItemHeight(self.item_height)

        self.icon_dir = LoadPixmap(os.path.join(SUBSPRO_IMG_DIR, "directory.png"))
        self.icon_srt = LoadPixmap(os.path.join(SUBSPRO_IMG_DIR, "subtitles.png"))

        self.current_directory = None
        self.onSelectionChanged = []
        self.changeDir(directory)

    def changeDir(self, directory):
        if not directory or not os.path.exists(directory):
            directory = "/media/"
            if not os.path.exists(directory):
                directory = "/"

        self.current_directory = os.path.normpath(directory)
        items = []

        if self.current_directory not in ("/", "\\"):
            parent = os.path.dirname(self.current_directory)
            items.append(("..  <Parent directory>", parent, True))

        if self.current_directory in ("/", "/media"):
            try:
                from Components.Harddisk import harddiskmanager
                try:
                    parts = harddiskmanager.getMountedPartitions(only_usable=False)
                except TypeError:
                    parts = harddiskmanager.getMountedPartitions()
                for part in parts:
                    mp = os.path.normpath(part.mountpoint)
                    if mp and mp != "/" and os.path.exists(mp):
                        desc = "[Storage] {}".format(mp)
                        if hasattr(part, "description") and part.description:
                            desc = "[{}] {}".format(toString(part.description), mp)
                        if (desc, mp, True) not in items:
                            items.append((desc, mp, True))
            except Exception:
                pass

        dirs = []
        files = []
        try:
            for name in os.listdir(self.current_directory):
                try:
                    full_path = os.path.join(self.current_directory, name)
                    if os.path.isdir(full_path):
                        if not name.startswith("."):
                            dirs.append((name, full_path, True))
                    elif os.path.isfile(full_path):
                        if name.lower().endswith(".srt"):
                            files.append((name, full_path, False))
                except Exception:
                    continue
        except Exception as e:
            print("[SubsSupportPro][SrtEditor] Listdir error:", e)

        dirs.sort(key=lambda x: x[0].lower())
        files.sort(key=lambda x: x[0].lower())

        all_items = items + dirs + files
        display_list = []
        for name, path, is_dir in all_items:
            display_list.append(self.buildEntry(name, path, is_dir))

        self.setList(display_list)
        for cb in self.onSelectionChanged:
            cb()

    def buildEntry(self, name, full_path, is_dir):
        icon = self.icon_dir if is_dir else self.icon_srt
        h = self.item_height
        icon_size = 32 if self.scale >= 1.0 else 24
        if is4K():
            icon_size = 64
        icon_x = _sc(14, self.scale)
        icon_y = max(0, (h - icon_size) // 2)
        text_x = icon_x + icon_size + _sc(14, self.scale)
        text_w = _sc(1500, self.scale)

        res = [(full_path, is_dir, name)]
        if icon is not None:
            res.append((
                eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST,
                icon_x, icon_y, icon_size, icon_size, icon
            ))
        res.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            text_x, 0, text_w, h, 0,
            RT_HALIGN_LEFT | RT_VALIGN_CENTER, toString(name)
        ))
        return res

    def canDescent(self):
        cur = self.getCurrent()
        return bool(cur and len(cur) > 0 and len(cur[0]) > 1 and cur[0][1])

    def descent(self):
        if self.canDescent():
            cur = self.getCurrent()
            target_path = cur[0][0]
            if os.path.isdir(target_path):
                self.changeDir(target_path)

    def getFilename(self):
        cur = self.getCurrent()
        if cur and len(cur) > 0 and len(cur[0]) > 0:
            return cur[0][0]
        return None

    def getCurrentDirectory(self):
        return self.current_directory or "/"


# =========================================================================
# SUBSSUPPORTPRO-THEMED SKIN BUILDERS (HD / FHD / 2K / 4K + DREAMOS SAFE)
# =========================================================================

def _build_main_frame_skin(screen_name, title, scale, body_xml, buttons, pills=None):
    """Build a SubsSupportPro-style full frame (matches BaseProMenuScreen)."""
    w = _sc(1720, scale)
    h = _sc(980, scale)
    pad_in = _sc(20, scale)
    in_w = w - 2 * pad_in
    in_h = h - 2 * pad_in
    hdr_x = _sc(30, scale)
    hdr_y = _sc(30, scale)
    hdr_w = w - 2 * hdr_x
    hdr_h = _sc(68, scale)
    rad = _sc(20, scale)
    bw = 2 if scale >= 2.0 else 1
    div_h = max(1, _sc(2, scale))
    div_top_y = _sc(108, scale)
    div_bot_y = _sc(885, scale)
    box_x = _sc(45, scale)
    box_y = _sc(135, scale)
    box_w = w - 2 * box_x
    box_h = _sc(730, scale)

    title_x = _sc(45, scale)
    title_y = _sc(40, scale)
    title_w = _sc(1100, scale)
    title_h = _sc(48, scale)
    title_fs = _sc(32, scale)

    badge_x = _sc(1160, scale)
    badge_y = _sc(44, scale)
    badge_w = _sc(515, scale)
    badge_h = _sc(40, scale)
    badge_fs = _sc(24, scale)

    btn_y = _sc(898, scale)
    circle_d = _sc(50, scale)
    btn_fs = _sc(26, scale)

    btns_xml = ""
    btn_colors = {
        "key_red": "#a93247",
        "key_green": "#1aa96b",
        "key_yellow": "#c2941a",
        "key_blue": "#1f58d6",
    }
    for b_name, bx_fhd, blw_fhd in buttons:
        btns_xml += _build_color_button_xml(
            b_name, _sc(bx_fhd, scale), btn_y, circle_d,
            _sc(blw_fhd, scale), btn_fs, btn_colors[b_name], scale
        )

    pills_xml = ""
    if pills:
        pill_w = _sc(86, scale)
        pill_h = _sc(50, scale)
        pill_fs = _sc(22, scale)
        for p_txt, px_fhd in pills:
            pills_xml += _build_pill_badge_xml(
                p_txt, _sc(px_fhd, scale), btn_y, pill_w, pill_h, pill_fs, scale
            )

    raw = (
        '<screen name="{sname}" position="center,center" size="{w},{h}" title="{title}" zPosition="3" flags="wfNoBorder" backgroundColor="#ff000000">\n'
        '  <eLabel position="0,0" size="{w},{h}" backgroundColor="#061425" zPosition="-5" cornerRadius="{rad}" />\n'
        '  <eLabel position="{pi},{pi}" size="{iw},{ih}" backgroundColor="#0a1b2d" zPosition="-4" />\n'
        '  <eLabel position="{hx},{hy}" size="{hw},{hh}" backgroundColor="#8e5245" zPosition="-3" cornerRadius="{rad}" borderWidth="{bw}" borderColor="#27408b" />\n'
        '  <eLabel position="{pi},{dty}" size="{iw},{dh}" backgroundColor="#5d37d9" zPosition="-3" />\n'
        '  <widget name="title_label" position="{tx},{ty}" size="{tw},{th}" font="Regular;{tfs}" foregroundColor="#eaf3ff" backgroundColor="#8e5245" valign="center" halign="left" transparent="1" zPosition="5" />\n'
        '  <widget name="status_badge" position="{bx},{by}" size="{bw2},{bh}" font="Regular;{bfs}" foregroundColor="#d6e4f7" backgroundColor="#8e5245" valign="center" halign="right" transparent="1" zPosition="5" />\n'
        '  <eLabel name="" position="{box_x},{box_y}" size="{box_w},{box_h}" zPosition="-1" backgroundColor="#061425" cornerRadius="{rad}" borderWidth="{bw}" borderColor="#27408b" />\n'
        '{body}'
        '  <eLabel position="{hx},{dby}" size="{hw},{dh}" backgroundColor="#5d37d9" zPosition="-3" />\n'
        '{btns}'
        '{pills}'
        '</screen>'
    ).format(
        sname=screen_name, w=w, h=h, title=title, rad=rad,
        pi=pad_in, iw=in_w, ih=in_h,
        hx=hdr_x, hy=hdr_y, hw=hdr_w, hh=hdr_h, bw=bw,
        dty=div_top_y, dby=div_bot_y, dh=div_h,
        tx=title_x, ty=title_y, tw=title_w, th=title_h, tfs=title_fs,
        bx=badge_x, by=badge_y, bw2=badge_w, bh=badge_h, bfs=badge_fs,
        box_x=box_x, box_y=box_y, box_w=box_w, box_h=box_h,
        body=body_xml, btns=btns_xml, pills=pills_xml
    )
    return _prepare_skin(raw)


def _build_dialog_skin(screen_name, title, scale, w_fhd, h_fhd, body_xml, buttons=None):
    """Build a SubsSupportPro-style compact dialog skin (matches DVBExternalStyleProScreen)."""
    w = _sc(w_fhd, scale)
    h = _sc(h_fhd, scale)
    pad_in = _sc(15, scale)
    in_w = w - 2 * pad_in
    in_h = h - 2 * pad_in
    hdr_x = _sc(24, scale)
    hdr_y = _sc(22, scale)
    hdr_w = w - 2 * hdr_x
    hdr_h = _sc(58, scale)
    rad = _sc(20, scale)
    bw = 2 if scale >= 2.0 else 1
    div_h = max(1, _sc(2, scale))
    div_top_y = _sc(90, scale)
    div_bot_y = h - _sc(92, scale)

    btns_xml = ""
    if buttons:
        btn_y = h - _sc(76, scale)
        circle_d = _sc(50, scale)
        btn_fs = _sc(26, scale)
        btn_colors = {
            "key_red": "#a93247",
            "key_green": "#1aa96b",
            "key_yellow": "#c2941a",
            "key_blue": "#1f58d6",
        }
        for b_name, bx_fhd, blw_fhd in buttons:
            btns_xml += _build_color_button_xml(
                b_name, _sc(bx_fhd, scale), btn_y, circle_d,
                _sc(blw_fhd, scale), btn_fs, btn_colors[b_name], scale
            )

    raw = (
        '<screen name="{sname}" position="center,center" size="{w},{h}" title="{title}" zPosition="4" flags="wfNoBorder" backgroundColor="#ff000000">\n'
        '  <eLabel position="0,0" size="{w},{h}" backgroundColor="#061425" zPosition="-5" cornerRadius="{rad}" />\n'
        '  <eLabel position="{pi},{pi}" size="{iw},{ih}" backgroundColor="#0a1b2d" zPosition="-4" />\n'
        '  <eLabel position="{hx},{hy}" size="{hw},{hh}" backgroundColor="#8e5245" zPosition="-3" cornerRadius="{rad}" borderWidth="{bw}" borderColor="#27408b" />\n'
        '  <eLabel position="{pi},{dty}" size="{iw},{dh}" backgroundColor="#5d37d9" zPosition="-3" />\n'
        '  <widget name="title" position="{tx},{ty}" size="{tw},{th}" font="Regular;{tfs}" foregroundColor="#eaf3ff" backgroundColor="#8e5245" valign="center" halign="center" transparent="1" zPosition="5" />\n'
        '{body}'
        '{div_bot}'
        '{btns}'
        '</screen>'
    ).format(
        sname=screen_name, w=w, h=h, title=title, rad=rad,
        pi=pad_in, iw=in_w, ih=in_h,
        hx=hdr_x, hy=hdr_y, hw=hdr_w, hh=hdr_h, bw=bw,
        dty=div_top_y, dh=div_h,
        tx=_sc(36, scale), ty=_sc(28, scale), tw=w - _sc(72, scale),
        th=_sc(46, scale), tfs=_sc(30, scale),
        body=body_xml,
        div_bot=('  <eLabel position="{hx},{dby}" size="{hw},{dh}" backgroundColor="#5d37d9" zPosition="-3" />\n'.format(
            hx=hdr_x, dby=div_bot_y, hw=hdr_w, dh=div_h) if buttons else ""),
        btns=btns_xml
    )
    return _prepare_skin(raw)


# =========================================================================
# UI SCREENS
# =========================================================================

# --- 1. FILE SELECTOR SCREEN ---

class SrtFileSelector(Screen):

    def __init__(self, session):
        scale, res_short, _res_full = _get_res_info()
        self.ui_scale = scale

        item_h = _sc(50, scale)
        list_h = item_h * 13  # 650px at FHD -> 13 full rows, zero cutoff
        sb_w = max(7, _sc(10, scale))
        irad = _sc(12, scale)

        body_xml = (
            '  <widget name="path_label" position="{px},{py}" size="{pw},{ph}" font="Regular;{pfs}" foregroundColor="#facc15" backgroundColor="#061425" valign="center" halign="left" transparent="1" />\n'
            '  <widget name="file_list" position="{lx},{ly}" size="{lw},{lh}" itemHeight="{ih}" scrollbarMode="showOnDemand" scrollbarWidth="{sbw}" backgroundColorSelected="#2c525b" backgroundColor="#061425" itemCornerRadius="{irad}" itemCornerRadiusSelected="{irad}" transparent="1" />\n'
        ).format(
            px=_sc(60, scale), py=_sc(148, scale), pw=_sc(1600, scale),
            ph=_sc(44, scale), pfs=_sc(26, scale),
            lx=_sc(55, scale), ly=_sc(202, scale), lw=_sc(1610, scale),
            lh=list_h, ih=item_h, sbw=sb_w, irad=irad
        )

        buttons = [
            ("key_red", 50, 290),
            ("key_green", 450, 290),
            ("key_yellow", 850, 290),
            ("key_blue", 1250, 320),
        ]
        self.skin = _build_main_frame_skin(
            "SrtFileSelector", "SRT Editor - Browse Subtitle File",
            scale, body_xml, buttons
        )
        Screen.__init__(self, session)

        paths = ["/media/hdd/movie", "/media/hdd", "/media/usb", "/media", "/home/root", "/"]
        init_dir = "/media/"
        for p in paths:
            if os.path.exists(p):
                init_dir = p
                break

        self["file_list"] = SrtFileList(init_dir, scale=scale)
        self["title_label"] = Label(toString(_("Select SRT Subtitle File")))
        self["path_label"] = Label(toString(init_dir))
        self["status_badge"] = Label(toString("[{}]  {}".format(_get_image_display_name(), res_short)))

        self["key_red"] = Label(toString(_("Close")))
        self["key_green"] = Label(toString(_("Modify Options")))
        self["key_yellow"] = Label(toString(_("Open Editor")))
        self["key_blue"] = Label(toString(_("Parent Folder")))

        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.ok,
            "green": self.openOptions,
            "yellow": self.openEditorDirect,
            "cancel": self.cancel,
            "red": self.cancel,
            "blue": self.parentFolder
        }, -2)

        self["file_list"].onSelectionChanged.append(self.updatePath)

    def updatePath(self):
        try:
            curr_dir = self["file_list"].getCurrentDirectory()
            if curr_dir:
                self["path_label"].setText(toString(curr_dir))
        except Exception:
            pass

    def parentFolder(self):
        curr_dir = self["file_list"].getCurrentDirectory()
        if curr_dir and curr_dir not in ("/", "\\"):
            parent = os.path.dirname(os.path.normpath(curr_dir))
            if os.path.exists(parent):
                self["file_list"].changeDir(parent)

    def ok(self):
        if self["file_list"].canDescent():
            self["file_list"].descent()
        else:
            self.openOptions()

    def openOptions(self):
        if self["file_list"].canDescent():
            self["file_list"].descent()
            return
        filepath = self["file_list"].getFilename()
        if filepath and filepath.lower().endswith('.srt'):
            if not os.path.isfile(filepath):
                self.session.open(
                    MessageBox, toString("Selected file does not exist.\n{}".format(filepath)),
                    MessageBox.TYPE_ERROR
                )
                return
            if os.path.getsize(filepath) == 0:
                self.session.open(
                    MessageBox, toString("Selected file is empty (0 bytes)."),
                    MessageBox.TYPE_WARNING
                )
                return
            self.session.open(SrtModifyOptionsScreen, filepath)

    def openEditorDirect(self):
        if self["file_list"].canDescent():
            self["file_list"].descent()
            return
        filepath = self["file_list"].getFilename()
        if filepath and filepath.lower().endswith('.srt'):
            if not os.path.isfile(filepath):
                self.session.open(
                    MessageBox, toString("Selected file does not exist.\n{}".format(filepath)),
                    MessageBox.TYPE_ERROR
                )
                return
            if os.path.getsize(filepath) == 0:
                self.session.open(
                    MessageBox, toString("Selected file is empty (0 bytes)."),
                    MessageBox.TYPE_WARNING
                )
                return
            self.session.open(SrtEditorScreen, filepath)

    def cancel(self):
        self.close()


# --- 2. MODIFICATION OPTIONS SCREEN ---

class SrtModifyOptionsScreen(ConfigListScreen, Screen):

    def __init__(self, session, filepath):
        scale, res_short, _res_full = _get_res_info()
        self.ui_scale = scale

        item_h = _sc(48, scale)
        cfg_h = item_h * 13  # 624px at FHD -> all 13 entries visible
        sb_w = max(7, _sc(10, scale))
        irad = _sc(12, scale)
        cfg_fs = _sc(26, scale)

        body_xml = (
            '  <widget name="file_info" position="{ix},{iy}" size="{iw},{ih}" font="Regular;{ifs}" foregroundColor="#facc15" backgroundColor="#061425" valign="center" halign="left" transparent="1" />\n'
            '  <widget name="config" position="{cx},{cy}" size="{cw},{ch}" font="Regular;{cfs}" secondfont="Regular;{cfs}" itemHeight="{cih}" scrollbarMode="showOnDemand" scrollbarWidth="{sbw}" backgroundColorSelected="#2c525b" backgroundColor="#061425" itemCornerRadius="{irad}" itemCornerRadiusSelected="{irad}" />\n'
        ).format(
            ix=_sc(60, scale), iy=_sc(145, scale), iw=_sc(1600, scale),
            ih=_sc(72, scale), ifs=_sc(24, scale),
            cx=_sc(55, scale), cy=_sc(228, scale), cw=_sc(1610, scale),
            ch=cfg_h, cfs=cfg_fs, cih=item_h, sbw=sb_w, irad=irad
        )

        buttons = [
            ("key_red", 50, 290),
            ("key_green", 450, 290),
            ("key_yellow", 850, 290),
            ("key_blue", 1250, 320),
        ]
        self.skin = _build_main_frame_skin(
            "SrtModifyOptionsScreen", "SRT Editor - Subtitle Modifications",
            scale, body_xml, buttons
        )
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self.filepath = filepath
        self.subs, self.detected_encoding = parse_srt(filepath)

        self["title_label"] = Label(toString(_("Configure Modifications")))
        self["status_badge"] = Label(toString("{} | Lines: {} | Enc: {}".format(
            res_short, len(self.subs), self.detected_encoding)))

        bak_exists = os.path.exists(self.filepath + ".bak")
        bak_str = "[Backup exists]" if bak_exists else "[No backup yet]"
        self["file_info"] = Label(toString("File: {}\nBackup Status: {}".format(
            os.path.basename(self.filepath), bak_str
        )))

        self.cfg_backup = ConfigYesNo(default=True)
        self.cfg_clean_arabic = ConfigYesNo(default=True)
        self.cfg_remove_tashkeel = ConfigYesNo(default=False)
        self.cfg_remove_tatweel = ConfigYesNo(default=True)
        self.cfg_remove_html = ConfigYesNo(default=True)
        self.cfg_remove_ass = ConfigYesNo(default=True)
        self.cfg_remove_hi = ConfigYesNo(default=True)
        self.cfg_remove_speakers = ConfigYesNo(default=False)
        self.cfg_remove_ads = ConfigYesNo(default=True)
        self.cfg_fix_overlaps = ConfigYesNo(default=True)

        shift_choices = [
            ("-10000", "-10.0 Seconds (-10000ms)"),
            ("-5000",  "-5.0 Seconds (-5000ms)"),
            ("-2000",  "-2.0 Seconds (-2000ms)"),
            ("-1000",  "-1.0 Second (-1000ms)"),
            ("-500",   "-0.5 Seconds (-500ms)"),
            ("-200",   "-0.2 Seconds (-200ms)"),
            ("0",      "None (0 ms)"),
            ("200",    "+0.2 Seconds (+200ms)"),
            ("500",    "+0.5 Seconds (+500ms)"),
            ("1000",   "+1.0 Second (+1000ms)"),
            ("2000",   "+2.0 Seconds (+2000ms)"),
            ("5000",   "+5.0 Seconds (+5000ms)"),
            ("10000",  "+10.0 Seconds (+10000ms)")
        ]
        self.cfg_shift = ConfigSelection(default="0", choices=shift_choices)

        fps_choices = [
            ("none", "None (Keep Original)"),
            ("25.000->23.976", "25.000 -> 23.976 (PAL to Film)"),
            ("23.976->25.000", "23.976 -> 25.000 (Film to PAL)"),
            ("24.000->25.000", "24.000 -> 25.000"),
            ("25.000->24.000", "25.000 -> 24.000"),
            ("23.976->24.000", "23.976 -> 24.000"),
            ("24.000->23.976", "24.000 -> 23.976")
        ]
        self.cfg_fps = ConfigSelection(default="none", choices=fps_choices)

        enc_choices = [
            ("utf-8", "UTF-8 (Universal / Recommended)"),
            ("cp1256", "Windows-1256 (Arabic Windows)")
        ]
        self.cfg_out_encoding = ConfigSelection(default="utf-8", choices=enc_choices)

        self.list = [
            getConfigListEntry(toString("Create Auto-Backup (.bak) before saving:"), self.cfg_backup),
            getConfigListEntry(toString("Clean Arabic Lines (Remove strange symbols at start/end):"), self.cfg_clean_arabic),
            getConfigListEntry(toString("Clean Arabic: Remove Tashkeel (Harakat):"), self.cfg_remove_tashkeel),
            getConfigListEntry(toString("Clean Arabic: Remove Tatweel / Kashida:"), self.cfg_remove_tatweel),
            getConfigListEntry(toString("Remove HTML Tags (<i>, <b>, <font>, etc.):"), self.cfg_remove_html),
            getConfigListEntry(toString("Remove ASS/SSA Style Tags ({\\anX}, etc.):"), self.cfg_remove_ass),
            getConfigListEntry(toString("Remove Hearing Impaired (HI) notes & sound fx ([Music]):"), self.cfg_remove_hi),
            getConfigListEntry(toString("Remove Speaker Names (e.g. JOHN:):"), self.cfg_remove_speakers),
            getConfigListEntry(toString("Remove Subtitle Ads & Web Links (e.g. opensubtitles):"), self.cfg_remove_ads),
            getConfigListEntry(toString("Fix Overlapping Subtitle Timecodes:"), self.cfg_fix_overlaps),
            getConfigListEntry(toString("Time Shift (Delay / Advance):"), self.cfg_shift),
            getConfigListEntry(toString("Frame Rate (FPS) Conversion:"), self.cfg_fps),
            getConfigListEntry(toString("Output File Encoding:"), self.cfg_out_encoding)
        ]
        self["config"].setList(self.list)

        self["key_red"] = Label(toString(_("Back")))
        self["key_green"] = Label(toString(_("Apply & Save")))
        self["key_yellow"] = Label(toString(_("Open in Editor")))
        self["key_blue"] = Label(toString(_("Restore Backup") if bak_exists else _("No Backup")))

        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.applyAndSave,
            "save": self.applyAndSave,
            "yellow": self.openInEditor,
            "blue": self.promptRestoreBackup,
            "red": self.close,
            "cancel": self.close
        }, -2)

    def getOptionsDict(self):
        fps_ratio = 1.0
        if self.cfg_fps.value != "none":
            try:
                src_fps, dst_fps = self.cfg_fps.value.split('->')
                fps_ratio = float(src_fps) / float(dst_fps)
            except Exception:
                fps_ratio = 1.0

        return {
            'clean_arabic': self.cfg_clean_arabic.value,
            'remove_tashkeel': self.cfg_remove_tashkeel.value,
            'remove_tatweel': self.cfg_remove_tatweel.value,
            'remove_html': self.cfg_remove_html.value,
            'remove_ass': self.cfg_remove_ass.value,
            'remove_hi': self.cfg_remove_hi.value,
            'remove_speakers': self.cfg_remove_speakers.value,
            'remove_ads': self.cfg_remove_ads.value,
            'fix_overlaps': self.cfg_fix_overlaps.value,
            'shift_ms': int(self.cfg_shift.value),
            'fps_ratio': fps_ratio
        }

    def applyAndSave(self):
        if not self.subs:
            self.session.open(
                MessageBox, toString("Empty or invalid subtitle file."), MessageBox.TYPE_ERROR
            )
            return

        options = self.getOptionsDict()
        modified_subs, stats = modify_subtitles(self.subs, options)

        if not modified_subs:
            self.session.open(
                MessageBox, toString("All subtitle lines were cleaned or removed. File not saved."),
                MessageBox.TYPE_WARNING
            )
            return

        out_enc = self.cfg_out_encoding.value
        create_bak = self.cfg_backup.value

        if save_srt(self.filepath, modified_subs, encoding=out_enc, backup=create_bak):
            msg = (
                "Subtitle successfully modified and saved!\n\n"
                "- Arabic lines cleaned: {}\n"
                "- Tags removed: {}\n"
                "- Sound FX/HI removed: {}\n"
                "- Speaker labels removed: {}\n"
                "- Ads removed: {}\n"
                "- Overlaps fixed: {}\n"
                "- Total lines saved: {}\n"
                "- Backup: {}\n"
                "- Encoding: {}"
            ).format(
                stats['cleaned_arabic'],
                stats['removed_tags'],
                stats['removed_hi'],
                stats['removed_speakers'],
                stats['removed_ads'],
                stats['overlapping_fixed'],
                len(modified_subs),
                "Created (.bak)" if create_bak else "Skipped",
                out_enc.upper()
            )
            self.session.open(MessageBox, toString(msg), MessageBox.TYPE_INFO, timeout=7)
            self.close()
        else:
            self.session.open(
                MessageBox, toString("Failed to save file. Check permissions or disk space."),
                MessageBox.TYPE_ERROR
            )

    def openInEditor(self):
        if not self.subs:
            self.session.open(
                MessageBox, toString("No subtitle lines found to edit."), MessageBox.TYPE_WARNING
            )
            return
        options = self.getOptionsDict()
        modified_subs, _stats = modify_subtitles(self.subs, options)
        subs_to_open = modified_subs if modified_subs else self.subs
        self.session.open(SrtEditorScreen, self.filepath, preloaded_subs=subs_to_open)

    def promptRestoreBackup(self):
        bak_file = self.filepath + ".bak"
        if not os.path.exists(bak_file):
            self.session.open(
                MessageBox, toString("No backup file found (.bak)."), MessageBox.TYPE_INFO, timeout=3
            )
            return

        self.session.openWithCallback(
            self.restoreCallback,
            MessageBox,
            toString("Are you sure you want to restore the original backup?\n{}".format(bak_file)),
            MessageBox.TYPE_YESNO
        )

    def restoreCallback(self, answer):
        if answer:
            if restore_backup(self.filepath):
                self.session.open(
                    MessageBox, toString("Backup successfully restored!"), MessageBox.TYPE_INFO, timeout=4
                )
                self.subs, self.detected_encoding = parse_srt(self.filepath)
                self["status_badge"].setText(toString(
                    "Lines: {} | Enc: {}".format(len(self.subs), self.detected_encoding)
                ))
            else:
                self.session.open(
                    MessageBox, toString("Failed to restore backup file."), MessageBox.TYPE_ERROR
                )


# --- 3. MAIN INTERACTIVE SRT EDITOR SCREEN ---

class SrtEditorScreen(Screen):

    def __init__(self, session, filepath, preloaded_subs=None):
        scale, _res_short, _res_full = _get_res_info()
        self.ui_scale = scale
        self.item_h = _sc(52, scale)
        list_h = self.item_h * 13  # 676px at FHD -> 13 full rows
        sb_w = max(7, _sc(10, scale))
        irad = _sc(12, scale)

        body_xml = (
            '  <widget name="list" position="{lx},{ly}" size="{lw},{lh}" itemHeight="{ih}" scrollbarMode="showOnDemand" scrollbarWidth="{sbw}" backgroundColorSelected="#2c525b" backgroundColor="#061425" itemCornerRadius="{irad}" itemCornerRadiusSelected="{irad}" transparent="1" />\n'
            '  <widget name="hint_label" position="{hx},{hy}" size="{hw},{hh}" font="Regular;{hfs}" halign="center" valign="center" foregroundColor="#d6e4f7" transparent="1" />\n'
        ).format(
            lx=_sc(55, scale), ly=_sc(145, scale), lw=_sc(1610, scale),
            lh=list_h, ih=self.item_h, sbw=sb_w, irad=irad,
            hx=_sc(55, scale), hy=_sc(826, scale), hw=_sc(1610, scale),
            hh=_sc(36, scale), hfs=_sc(22, scale)
        )

        buttons = [
            ("key_red", 50, 220),
            ("key_green", 340, 220),
            ("key_yellow", 630, 240),
            ("key_blue", 940, 240),
        ]
        pills = [
            ("INFO", 1480),
            ("MENU", 1580),
        ]
        self.skin = _build_main_frame_skin(
            "SrtEditorScreen", "SRT Editor",
            scale, body_xml, buttons, pills=pills
        )
        Screen.__init__(self, session)
        self.filepath = filepath

        if preloaded_subs is not None:
            self.subs = preloaded_subs
            self.detected_encoding = "utf-8"
        else:
            self.subs, self.detected_encoding = parse_srt(filepath)

        self["title_label"] = Label(toString(os.path.basename(self.filepath)))
        self["status_badge"] = Label(toString("Total: {} lines".format(len(self.subs))))
        self["hint_label"] = Label(toString(_("OK: Edit Line  |  MENU: Tools  |  INFO: About")))

        self["key_red"] = Label(toString(_("Delete")))
        self["key_green"] = Label(toString(_("Save")))
        self["key_yellow"] = Label(toString(_("Modify Menu")))
        self["key_blue"] = Label(toString(_("Time Sync")))

        self["list"] = MenuList([], content=eListboxPythonMultiContent)
        self["list"].l.setFont(0, gFont("Regular", _sc(22, scale)))
        self["list"].l.setFont(1, gFont("Regular", _sc(25, scale)))
        self["list"].l.setItemHeight(self.item_h)

        self.updateList()

        self["actions"] = ActionMap(["ColorActions", "SetupActions", "InfobarEPGActions", "MenuActions"], {
            "red": self.deletePrompt,
            "green": self.saveFile,
            "yellow": self.openModifyOptions,
            "blue": self.openSyncSetup,
            "info": self.openAbout,
            "showEventInfo": self.openAbout,
            "menu": self.openToolsMenu,
            "ok": self.editLine,
            "cancel": self.close
        }, -1)

        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        if not self.subs:
            self["title_label"].setText(toString("{} (Empty)".format(os.path.basename(self.filepath))))
            self["status_badge"].setText(toString("Total: 0 lines"))
            self["hint_label"].setText(toString(_("File is empty. Press EXIT to close.")))

    def updateList(self):
        display_list = [build_srt_entry(sub, self.ui_scale, self.item_h) for sub in self.subs]
        self["list"].setList(display_list)
        self["status_badge"].setText(toString("Total: {} lines".format(len(self.subs))))
        self.setTitle(toString("SRT Editor - {} ({} lines)".format(
            os.path.basename(self.filepath), len(self.subs)
        )))

    def deletePrompt(self):
        if not self.subs:
            return
        current = self["list"].getCurrent()
        if current:
            self.item_to_delete = current[0]
            self.session.openWithCallback(
                self.deleteCallback, MessageBox,
                toString(_("Are you sure you want to delete this line?")),
                MessageBox.TYPE_YESNO
            )

    def deleteCallback(self, answer):
        if answer and self.item_to_delete in self.subs:
            self.subs.remove(self.item_to_delete)
            for idx, sub in enumerate(self.subs, 1):
                sub['index'] = u"{}".format(idx)
            self.updateList()

    def editLine(self):
        current = self["list"].getCurrent()
        if current and self.subs:
            self.editing_sub = current[0]
            self.session.openWithCallback(
                self.editCallback, VirtualKeyBoard,
                title=toString(_("Edit Subtitle Text")),
                text=toString(self.editing_sub['text'])
            )
        else:
            self.session.open(MessageBox, toString(_("No subtitles to edit.")), MessageBox.TYPE_INFO)

    def editCallback(self, text):
        if text is not None:
            self.editing_sub['text'] = toUnicode(text)
            self.updateList()

    def saveFile(self):
        if not self.subs:
            self.session.open(
                MessageBox, toString(_("No subtitles to save.")), MessageBox.TYPE_WARNING
            )
            return
        if save_srt(self.filepath, self.subs, encoding='utf-8', backup=True):
            self.session.open(
                MessageBox, toString(_("Subtitle saved!\nBackup created as .bak")),
                MessageBox.TYPE_INFO, timeout=3
            )
            self.close()
        else:
            self.session.open(
                MessageBox, toString(_("Failed to write file. Check permissions.")),
                MessageBox.TYPE_ERROR
            )

    def openModifyOptions(self):
        self.session.open(SrtModifyOptionsScreen, self.filepath)
        self.close()

    def openAbout(self):
        self.session.open(SrtEditorAbout)

    def openToolsMenu(self):
        choices = [
            (toString(_("Modify & Clean Subtitle Options")), "options"),
            (toString(_("Insert New Subtitle Below")), "insert"),
            (toString(_("Jump to Line Number...")), "jump"),
            (toString(_("Convert FPS (Frame Rate)")), "fps"),
            (toString(_("Time Sync (Shift Offset)")), "sync"),
            (toString(_("Reload with Arabic Encoding (Win-1256)")), "encoding"),
            (toString(_("Restore Backup File (.bak)")), "restore")
        ]
        self.session.openWithCallback(self.toolsCallback, ChoiceBox, title=toString(_("SRT Tools")), list=choices)

    def toolsCallback(self, choice):
        if not choice:
            return
        action = choice[1]

        if action == "options":
            self.openModifyOptions()

        elif action == "insert":
            current = self["list"].getCurrent()
            if current:
                idx = self.subs.index(current[0])
                new_sub = {
                    'index': u"{}".format(len(self.subs) + 1),
                    'time': u"00:00:00,000 --> 00:00:05,000",
                    'text': u"New Subtitle Text"
                }
                self.subs.insert(idx + 1, new_sub)
                for i, s in enumerate(self.subs, 1):
                    s['index'] = u"{}".format(i)
                self.updateList()

        elif action == "jump":
            self.session.openWithCallback(
                self.jumpCallback, VirtualKeyBoard,
                title=toString(_("Enter Line Number to Jump To:")), text=""
            )

        elif action == "fps":
            self.openFpsSetup()

        elif action == "sync":
            self.openSyncSetup()

        elif action == "encoding":
            self.subs, self.detected_encoding = parse_srt(self.filepath, force_encoding='cp1256')
            self.updateList()
            self.session.open(
                MessageBox,
                toString(_("File reloaded with Arabic Encoding (Windows-1256).\nPress Green to save as clean UTF-8.")),
                MessageBox.TYPE_INFO, timeout=4
            )

        elif action == "restore":
            if restore_backup(self.filepath):
                self.session.open(
                    MessageBox, toString(_("Backup restored successfully!")), MessageBox.TYPE_INFO, timeout=3
                )
                self.subs, self.detected_encoding = parse_srt(self.filepath)
                self.updateList()
            else:
                self.session.open(
                    MessageBox, toString(_("No backup file found or restore failed.")), MessageBox.TYPE_ERROR
                )

    def jumpCallback(self, text):
        if text and text.isdigit():
            target_idx = int(text) - 1
            if 0 <= target_idx < len(self.subs):
                self["list"].moveToIndex(target_idx)
            else:
                self.session.open(
                    MessageBox, toString(_("Line number out of bounds.")), MessageBox.TYPE_ERROR, timeout=3
                )

    def openFpsSetup(self):
        self.session.openWithCallback(self.fpsCallback, FpsInputScreen)

    def fpsCallback(self, old_fps_str, new_fps_str):
        if not old_fps_str or not new_fps_str:
            return
        try:
            for sub in self.subs:
                sub['time'] = convert_time_fps(
                    sub['time'], old_fps_str, new_fps_str)
            self.updateList()
            self.session.open(
                MessageBox, toString(_("FPS Converted successfully.")), MessageBox.TYPE_INFO, timeout=3)
        except Exception:
            pass

    def openSyncSetup(self):
        self.session.openWithCallback(self.syncCallback, TimeSyncScreen)

    def syncCallback(self, offset_ms):
        if offset_ms is not None and offset_ms != 0:
            for sub in self.subs:
                sub['time'] = shift_timecode(sub['time'], offset_ms)
            self.updateList()
            self.session.open(
                MessageBox, toString(_("Time Shift applied successfully.")), MessageBox.TYPE_INFO, timeout=3)


# --- 4. CONFIG & INPUT SCREENS ---

class FpsInputScreen(ConfigListScreen, Screen):

    def __init__(self, session):
        scale, _res_short, _res_full = _get_res_info()
        item_h = _sc(52, scale)
        sb_w = max(7, _sc(10, scale))
        irad = _sc(12, scale)
        cfs = _sc(26, scale)

        body_xml = (
            '  <widget name="config" position="{cx},{cy}" size="{cw},{ch}" font="Regular;{cfs}" secondfont="Regular;{cfs}" itemHeight="{ih}" scrollbarMode="showNever" scrollbarWidth="{sbw}" backgroundColorSelected="#2c525b" backgroundColor="#061425" itemCornerRadius="{irad}" itemCornerRadiusSelected="{irad}" />\n'
        ).format(
            cx=_sc(36, scale), cy=_sc(118, scale), cw=_sc(828, scale),
            ch=item_h * 2 + _sc(12, scale), cfs=cfs, ih=item_h, sbw=sb_w, irad=irad
        )

        buttons = [
            ("key_red", 60, 260),
            ("key_green", 500, 260),
        ]
        self.skin = _build_dialog_skin(
            "FpsInputScreen", "Convert Subtitle FPS",
            scale, 900, 360, body_xml, buttons=buttons
        )
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self["title"] = Label(toString(_("Convert Subtitle FPS")))

        fps_choices = [
            "23.976", "24.000", "25.000",
            "29.970", "30.000", "50.000", "59.940", "60.000"
        ]
        self.old_fps = ConfigSelection(default="25.000", choices=fps_choices)
        self.new_fps = ConfigSelection(default="23.976", choices=fps_choices)
        self.list = [
            getConfigListEntry(toString(_("Current (Source) FPS:")), self.old_fps),
            getConfigListEntry(toString(_("Target (Output) FPS:")), self.new_fps)
        ]
        self["config"].setList(self.list)
        self["key_red"] = Label(toString(_("Cancel")))
        self["key_green"] = Label(toString(_("Convert")))
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.keyGo, "save": self.keyGo,
            "red": self.keyCancel, "cancel": self.keyCancel
        }, -2)

    def keyGo(self):
        self.close(self.old_fps.value, self.new_fps.value)

    def keyCancel(self):
        self.close(None, None)


class TimeSyncScreen(ConfigListScreen, Screen):

    def __init__(self, session):
        scale, _res_short, _res_full = _get_res_info()
        item_h = _sc(52, scale)
        sb_w = max(7, _sc(10, scale))
        irad = _sc(12, scale)
        cfs = _sc(26, scale)

        body_xml = (
            '  <widget name="config" position="{cx},{cy}" size="{cw},{ch}" font="Regular;{cfs}" secondfont="Regular;{cfs}" itemHeight="{ih}" scrollbarMode="showNever" scrollbarWidth="{sbw}" backgroundColorSelected="#2c525b" backgroundColor="#061425" itemCornerRadius="{irad}" itemCornerRadiusSelected="{irad}" />\n'
        ).format(
            cx=_sc(36, scale), cy=_sc(132, scale), cw=_sc(828, scale),
            ch=item_h + _sc(12, scale), cfs=cfs, ih=item_h, sbw=sb_w, irad=irad
        )

        buttons = [
            ("key_red", 60, 260),
            ("key_green", 500, 260),
        ]
        self.skin = _build_dialog_skin(
            "TimeSyncScreen", "Time Sync (Shift)",
            scale, 900, 340, body_xml, buttons=buttons
        )
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self["title"] = Label(toString(_("Time Sync (Shift)")))

        sync_choices = [
            ("-10000", "-10.0 Seconds (-10000ms)"),
            ("-5000",  "-5.0 Seconds (-5000ms)"),
            ("-2000",  "-2.0 Seconds (-2000ms)"),
            ("-1000",  "-1.0 Second (-1000ms)"),
            ("-500",   "-0.5 Seconds (-500ms)"),
            ("-200",   "-0.2 Seconds (-200ms)"),
            ("0",      "None (0 ms)"),
            ("200",    "+0.2 Seconds (+200ms)"),
            ("500",    "+0.5 Seconds (+500ms)"),
            ("1000",   "+1.0 Second (+1000ms)"),
            ("2000",   "+2.0 Seconds (+2000ms)"),
            ("5000",   "+5.0 Seconds (+5000ms)"),
            ("10000",  "+10.0 Seconds (+10000ms)")
        ]
        self.offset = ConfigSelection(default="0", choices=sync_choices)
        self.list = [getConfigListEntry(toString(_("Shift Subtitle Timing:")), self.offset)]
        self["config"].setList(self.list)

        self["key_red"] = Label(toString(_("Cancel")))
        self["key_green"] = Label(toString(_("Apply")))
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.keyGo, "save": self.keyGo,
            "red": self.keyCancel, "cancel": self.keyCancel
        }, -2)

    def keyGo(self):
        self.close(int(self.offset.value))

    def keyCancel(self):
        self.close(None)


# --- 5. ABOUT SCREEN ---

class SrtEditorAbout(Screen):

    def __init__(self, session):
        scale, _res_short, res_full = _get_res_info()

        body_xml = (
            '  <widget name="desc" position="{dx},{dy}" size="{dw},{dh}" font="Regular;{dfs}" foregroundColor="#eaf3ff" backgroundColor="#061425" transparent="1" />\n'
            '  <widget name="footer" position="{fx},{fy}" size="{fw},{fh}" font="Regular;{ffs}" halign="center" valign="center" foregroundColor="#d6e4f7" backgroundColor="#061425" transparent="1" />\n'
        ).format(
            dx=_sc(40, scale), dy=_sc(110, scale), dw=_sc(880, scale),
            dh=_sc(360, scale), dfs=_sc(24, scale),
            fx=_sc(40, scale), fy=_sc(485, scale), fw=_sc(880, scale),
            fh=_sc(45, scale), ffs=_sc(22, scale)
        )
        self.skin = _build_dialog_skin(
            "SrtEditorAbout", "About SRT Editor",
            scale, 960, 560, body_xml
        )
        Screen.__init__(self, session)

        self["title"] = Label(toString("SubsSupportPro - SRT Editor"))
        self["desc"] = Label(toString(
            "Advanced Enigma2 Subtitle Editor & Batch Cleaner\n\n"
            "- Auto-Backup (.bak) and instant restore\n"
            "- Arabic lines cleanup (strips strange symbols & BiDi marks)\n"
            "- Removes HTML tags, SSA/ASS codes & Hearing Impaired FX\n"
            "- Removes ads, web credits & fixes overlapping timecodes\n"
            "- Time sync (shift) & FPS conversion\n"
            "- Full line-by-line interactive editor with VirtualKeyBoard\n\n"
            "Detected Image: {}\nResolution Mode: {}".format(_get_image_display_name(), res_full)
        ))
        self["footer"] = Label(toString("Compatible with OpenSource & DreamOS (Python 2 & 3)"))
        self["actions"] = ActionMap(
            ["SetupActions"], {"ok": self.close, "cancel": self.close}, -1
        )


# =========================================================================
# PLUGIN ENTRY POINT (EMBEDDED IN SUBSSUPPORTPRO)
# =========================================================================

def main(session, **kwargs):
    session.open(SrtFileSelector)
