# -*- coding: utf-8 -*-
import threading
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning  # type: ignore

from Screens.MessageBox import MessageBox
from Screens.Console import Console

from .version import PLUGIN_VERSION, PLUGIN_NAME
from .compat import eConnectCallback
from . import _

# Suppress unverified HTTPS request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

try:
    from enigma import eTimer  # type: ignore
except Exception:
    eTimer = None

UPDATE_JSON_URL = "https://raw.githubusercontent.com/popking159/SubsSupportPro/main/update.json"


class PluginUpdater:
    def __init__(self, session, ui_screen):
        self.session = session
        self.ui_screen = ui_screen
        self.update_data = None
        self.check_finished = False
        self.poll_handled = False
        self.timer = None
        self.timer_conn = None
        self.timer_failed = False

        self.ui_screen.setUpdateStatus(_("Checking for update..."))

        # Python 2 / 3 compatible thread initialization
        t = threading.Thread(target=self._check_remote)
        t.daemon = True
        t.start()

        self._start_poll_timer()

        # The worker may already be done when the timer setup failed.
        if self.timer_failed and self.check_finished:
            self._finish_without_timer()

    def _start_poll_timer(self):
        """
        Start the timer polling the worker thread result.

        The timer callback API is different between images:
          - OpenSource (OE-A): timer.timeout.connect(callback)
          - DreamOS / VTi:     timer.timeout.get().append(callback)
                               or timer.callback.append(callback)
        eConnectCallback handles all variants and the returned connection
        object is kept on self, otherwise DreamOS can garbage collect it and
        the status label would stay stuck on "Checking for update...".
        """
        if eTimer is None:
            self.timer_failed = True
            return

        try:
            self.timer = eTimer()
        except Exception as e:
            print("[SubsSupportPro] Update timer creation failed: " + str(e))
            self.timer = None
            self.timer_failed = True
            return

        try:
            self.timer_conn = eConnectCallback(
                self.timer.timeout, self._poll_result)
        except Exception:
            try:
                self.timer.callback.append(self._poll_result)
            except Exception as e:
                print("[SubsSupportPro] Update timer connect failed: " + str(e))
                self.timer = None
                self.timer_failed = True
                return

        started = False
        try:
            self.timer.start(1000, False)
            started = True
        except Exception:
            pass
        if not started:
            try:
                self.timer.start(1000)
                started = True
            except Exception as e:
                print("[SubsSupportPro] Update timer start failed: " + str(e))

        if not started:
            self.timer = None
            self.timer_failed = True

    def _stop_poll_timer(self):
        try:
            if self.timer is not None:
                self.timer.stop()
        except Exception:
            pass

    def _check_remote(self):
        try:
            # Use requests for unified Py2/Py3 SSL handling and JSON decoding
            r = requests.get(UPDATE_JSON_URL, headers={
                             "User-Agent": "Enigma2"}, timeout=5, verify=False)
            if r.status_code == 200:
                self.update_data = r.json()
        except Exception as e:
            print("[SubsSupportPro] Update fetch failed: " + str(e))

        self.check_finished = True

        # Last resort: no usable eTimer (unusual image), update the label only.
        if self.timer_failed:
            self._finish_without_timer()

    def _finish_without_timer(self):
        """Best-effort status update when no timer is available."""
        if self.poll_handled:
            return
        self.poll_handled = True
        try:
            if self.update_data:
                remote_v = self.update_data.get("version", "0.0.0")
                if self._is_newer(PLUGIN_VERSION, remote_v):
                    self.ui_screen.setUpdateStatus(_("Update available"))
                else:
                    self.ui_screen.setUpdateStatus(_("Plugin up to date"))
            else:
                self.ui_screen.setUpdateStatus(_("Update check failed"))
        except Exception:
            pass

    def _poll_result(self):
        if not self.check_finished or self.poll_handled:
            return
        self.poll_handled = True
        self._stop_poll_timer()

        if self.update_data:
            remote_v = self.update_data.get("version", "0.0.0")
            if self._is_newer(PLUGIN_VERSION, remote_v):
                self.ui_screen.setUpdateStatus(_("Update available"))
                changelog = self.update_data.get(
                    "changelog", "Updates available.")

                msg = _("New version available for %s (v%s)\n\nChangelog:\n%s\n\nDo you want to update now?") % (
                    PLUGIN_NAME, remote_v, changelog
                )
                self.session.openWithCallback(
                    self._on_user_choice, MessageBox, msg, MessageBox.TYPE_YESNO)
            else:
                self.ui_screen.setUpdateStatus(_("Plugin up to date"))
        else:
            self.ui_screen.setUpdateStatus(_("Update check failed"))

    def _is_newer(self, local, remote):
        try:
            l_parts = [int(x) for x in local.split(".") if x.isdigit()]
            r_parts = [int(x) for x in remote.split(".") if x.isdigit()]
            return r_parts > l_parts
        except Exception:
            return False

    def _on_user_choice(self, answer):
        if answer and self.update_data.get("script_url"):
            self.ui_screen.setUpdateStatus(_("Downloading update..."))
            cmd = "wget -qO - %s | bash" % self.update_data["script_url"]
            self.session.open(Console, title=_("Updating %s...") %
                              PLUGIN_NAME, cmdlist=[cmd], closeOnSuccess=False)
