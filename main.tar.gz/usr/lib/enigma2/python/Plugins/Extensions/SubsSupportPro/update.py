# -*- coding: utf-8 -*-
import threading
import json
import ssl
from urllib.request import Request, urlopen

from Screens.MessageBox import MessageBox
from Screens.Console import Console

from .version import PLUGIN_VERSION, PLUGIN_NAME
from . import _

try:
    from enigma import eTimer  # type: ignore
except Exception:
    eTimer = None

UPDATE_JSON_URL = "https://raw.githubusercontent.com/popking159/SubsSupportPro/main/update.json"


class PluginUpdater:
    def __init__(self, session, ui_screen):
        self.session = session
        self.ui_screen = ui_screen
        self.update_data = None
        self.check_finished = False

        self.ui_screen.setUpdateStatus(_("Checking for update..."))

        threading.Thread(target=self._check_remote, daemon=True).start()

        if eTimer is not None:
            self.timer = eTimer()
            try:
                self.timer.timeout.connect(self._poll_result)
            except AttributeError:
                self.timer.callback.append(self._poll_result)
            self.timer.start(1000, False)

    def _check_remote(self):
        try:
            req = Request(UPDATE_JSON_URL, headers={"User-Agent": "Enigma2"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with urlopen(req, timeout=5, context=ctx) as r:
                self.update_data = json.loads(r.read().decode('utf-8'))
        except Exception:
            pass
        self.check_finished = True

    def _poll_result(self):
        if not self.check_finished:
            return
        self.timer.stop()

        if self.update_data:
            remote_v = self.update_data.get("version", "0.0.0")
            if self._is_newer(PLUGIN_VERSION, remote_v):
                self.ui_screen.setUpdateStatus(_("Update available"))
                changelog = self.update_data.get(
                    "changelog", "Updates available.")

                msg = _("New version available for %s (v%s)\n\nChangelog:\n%s\n\nDo you want to update now?") % (
                    PLUGIN_NAME, remote_v, changelog
                )
                self.session.openWithCallback(
                    self._on_user_choice, MessageBox, msg, MessageBox.TYPE_YESNO)
            else:
                self.ui_screen.setUpdateStatus(_("Plugin up to date"))
        else:
            self.ui_screen.setUpdateStatus(_("Update check failed"))

    def _is_newer(self, local, remote):
        try:
            l_parts = [int(x) for x in local.split(".") if x.isdigit()]
            r_parts = [int(x) for x in remote.split(".") if x.isdigit()]
            return r_parts > l_parts
        except Exception:
            return False

    def _on_user_choice(self, answer):
        if answer and self.update_data.get("script_url"):
            self.ui_screen.setUpdateStatus(_("Downloading update..."))
            cmd = "wget -qO - %s | bash" % self.update_data["script_url"]
            self.session.open(Console, title=_("Updating %s...") %
                              PLUGIN_NAME, cmdlist=[cmd], closeOnSuccess=False)
