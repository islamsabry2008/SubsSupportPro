# -*- coding: utf-8 -*-
PLUGIN_NAME = "SubsSupportPro"
PLUGIN_VERSION = "1.4.0"
PLUGIN_VERSION_TITLE = "SubsSupportPro %s" % PLUGIN_VERSION
