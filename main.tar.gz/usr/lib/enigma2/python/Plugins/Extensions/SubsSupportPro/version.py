# -*- coding: utf-8 -*-
PLUGIN_NAME = "SubsSupportPro"
PLUGIN_VERSION = "1.8.0"
PLUGIN_VERSION_TITLE = "{} {}".format(PLUGIN_NAME, PLUGIN_VERSION)
