# -*- coding: utf-8 -*-
VER = "1.1.0"
PLUGIN_VERSION_TITLE = "SubsSupportPro %s" % VER
