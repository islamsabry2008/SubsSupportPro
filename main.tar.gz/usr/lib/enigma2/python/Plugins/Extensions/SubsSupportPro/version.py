# -*- coding: utf-8 -*-
VER = "1.4.0"
PLUGIN_VERSION_TITLE = "SubsSupportPro %s" % VER
