# -*- coding: utf-8 -*-
from __future__ import absolute_import
import json
import os
from twisted.web import server, resource
from twisted.internet import reactor
from Components.config import configfile

# Minimal, Dark-Themed Frontend
HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>SubsSupportPro WebUI</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { background-color: #121212; color: #e0e0e0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 1px solid #333; padding-bottom: 20px; }
        .header h1 { color: #ffffff; margin: 0; }
        .container { max-width: 800px; margin: 0 auto; }
        .provider-card { background: #1e1e1e; border: 1px solid #333; border-radius: 8px; padding: 20px; margin-bottom: 20px; display: flex; align-items: flex-start; gap: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }
        .logo-container { width: 100px; height: 100px; display: flex; justify-content: center; align-items: center; background: #2a2a2a; border-radius: 8px; overflow: hidden; flex-shrink: 0; }
        .provider-logo { max-width: 100%; max-height: 100%; object-fit: contain; }
        .content { flex-grow: 1; }
        .content h2 { margin: 0 0 15px 0; color: #fff; font-size: 1.4rem; }
        .field-group { margin-bottom: 15px; }
        .field-group label { display: block; margin-bottom: 5px; color: #aaa; font-size: 0.9rem; font-weight: bold; text-transform: uppercase; }
        .field-group input { width: 100%; box-sizing: border-box; padding: 10px; border-radius: 4px; border: 1px solid #444; background: #121212; color: #fff; font-size: 1rem; }
        .field-group input:focus { border-color: #007bff; outline: none; }
        .actions { display: flex; gap: 10px; margin-top: 20px; }
        button { padding: 10px 20px; border: none; border-radius: 4px; font-size: 1rem; cursor: pointer; font-weight: bold; transition: opacity 0.2s; }
        button:hover { opacity: 0.8; }
        .btn-save { background: #007bff; color: white; }
        .btn-test { background: #ffc107; color: black; }
        .status { margin-top: 10px; font-size: 0.9rem; display: none; padding: 10px; border-radius: 4px; }
        .status.success { background: rgba(40, 167, 69, 0.2); color: #28a745; display: block; border: 1px solid #28a745; }
        .status.error { background: rgba(220, 53, 69, 0.2); color: #dc3545; display: block; border: 1px solid #dc3545; }
        .status.info { background: rgba(23, 162, 184, 0.2); color: #17a2b8; display: block; border: 1px solid #17a2b8; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>SubsSupportPro Configuration</h1>
            <p>Manage API Keys and Credentials</p>
        </div>
        <div id="providers-list">Loading providers...</div>
    </div>

    <script>
        function showStatus(providerId, message, type) {
            const statusEl = document.getElementById(`status_${providerId}`);
            statusEl.textContent = message;
            statusEl.className = `status ${type}`;
        }

        async function saveSettings(providerId) {
            const inputs = document.querySelectorAll(`input[data-provider="${providerId}"]`);
            const settings = {};
            inputs.forEach(input => { settings[input.name] = input.value; });

            showStatus(providerId, "Saving...", "info");
            try {
                const res = await fetch('/api/save', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({provider: providerId, settings: settings})
                });
                const result = await res.json();
                if (result.success) showStatus(providerId, "Settings saved successfully!", "success");
                else showStatus(providerId, "Failed to save settings: " + result.message, "error");
            } catch(e) {
                showStatus(providerId, "Connection error.", "error");
            }
        }

        async function testSettings(providerId) {
            showStatus(providerId, "Testing credentials... Please wait.", "info");
            try {
                const res = await fetch('/api/test', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({provider: providerId})
                });
                const result = await res.json();
                if (result.success) showStatus(providerId, result.message, "success");
                else showStatus(providerId, result.message, "error");
            } catch(e) {
                showStatus(providerId, "Connection error or timeout.", "error");
            }
        }

        async function loadProviders() {
            try {
                const res = await fetch('/api/providers');
                const providers = await res.json();
                const container = document.getElementById('providers-list');
                container.innerHTML = '';

                if(providers.length === 0) {
                    container.innerHTML = '<p style="text-align:center;">No providers requiring credentials found.</p>';
                    return;
                }

                providers.forEach(p => {
                    let html = `<div class="provider-card">
                        <div class="logo-container">
                            <img class="provider-logo" src="/logo?id=${p.id}" onerror="this.style.display='none'">
                        </div>
                        <div class="content">
                            <h2>${p.name}</h2>`;

                    for(let key in p.fields) {
                        let fieldData = p.fields[key];
                        // Auto-hide password fields visually
                        let inputType = key.toLowerCase().includes('pass') ? 'password' : 'text';
                        html += `<div class="field-group">
                            <label>${fieldData.label}</label>
                            <input type="${inputType}" data-provider="${p.id}" name="${key}" value="${fieldData.value}">
                        </div>`;
                    }

                    html += `<div class="actions">
                                <button class="btn-save" onclick="saveSettings('${p.id}')">Save Settings</button>
                                <button class="btn-test" onclick="testSettings('${p.id}')">Test Credentials</button>
                             </div>
                             <div id="status_${p.id}" class="status"></div>
                        </div>
                    </div>`;
                    container.innerHTML += html;
                });
            } catch (e) {
                document.getElementById('providers-list').innerHTML = '<p class="status error">Error loading providers. Make sure the plugin is active.</p>';
            }
        }

        document.addEventListener('DOMContentLoaded', loadProviders);
    </script>
</body>
</html>
"""


class SubsProWebUI(resource.Resource):
    isLeaf = True

    def _get_seeker_instance(self):
        from .subtitles import initSubsProSettings, E2SubsSeeker
        settings = initSubsProSettings()
        return E2SubsSeeker(None, settings.search, debug=False)

    def _get_logo_path(self, provider):
        seekers_dir = os.path.join(os.path.dirname(__file__), 'seekers')
        candidates = []
        module_name = getattr(provider.__class__, '__module__', '')
        if '.seekers.' in module_name:
            try:
                candidates.append(module_name.split(
                    '.seekers.', 1)[1].split('.', 1)[0])
            except Exception:
                pass
        for attr in ('id', 'provider_name', 'name'):
            value = getattr(provider, attr, None)
            if value:
                candidates.append(str(value).strip().replace(
                    ' ', '').replace('-', '').replace('_', ''))

        try:
            folders = os.listdir(seekers_dir)
        except Exception:
            folders = []

        for candidate in candidates:
            if not candidate:
                continue
            candidate_key = candidate.lower()
            for folder in folders:
                if folder.lower() == candidate_key:
                    logo_path = os.path.join(seekers_dir, folder, 'logo.png')
                    if os.path.exists(logo_path):
                        return logo_path
        return None

    def render_GET(self, request):
        path = request.path.decode('utf-8', 'ignore')

        if path == "/":
            request.setHeader(b"Content-Type", b"text/html; charset=utf-8")
            return HTML_TEMPLATE.encode('utf-8')

        elif path == "/api/providers":
            seeker = self._get_seeker_instance()
            providers_data = []

            for p in seeker.seekers:
                try:
                    if not hasattr(p, 'settings_provider') or not hasattr(p, 'default_settings'):
                        continue

                    if not hasattr(p.settings_provider, 'getE2Settings'):
                        continue

                    e2_settings = p.settings_provider.getE2Settings()

                    # Sort default_settings by 'pos' to match the index of e2_settings perfectly
                    sorted_defaults = sorted(
                        p.default_settings.items(), key=lambda x: x[1].get('pos', 99))

                    fields = {}
                    for i, (internal_key, dict_val) in enumerate(sorted_defaults):
                        # Identify if this setting is a credential field
                        if any(x in internal_key.lower() for x in ['user', 'pass', 'api', 'key', 'token', 'secret']):
                            if i < len(e2_settings):
                                label = str(e2_settings[i][0])
                                obj = e2_settings[i][1]
                                fields[internal_key] = {
                                    "label": label,
                                    "value": str(obj.value) if obj.value is not None else ""
                                }

                    if fields:
                        providers_data.append({
                            "id": p.id,
                            "name": p.provider_name,
                            "fields": fields
                        })
                except Exception as e:
                    print(
                        "[SubsSupportPro] WebUI Error reading provider {}: {}".format(p.id, e))
                    continue

            request.setHeader(b"Content-Type", b"application/json")
            return json.dumps(providers_data).encode('utf-8')

        elif path == "/logo":
            provider_id = request.args.get(b'id', [b''])[0].decode('utf-8')
            seeker = self._get_seeker_instance()
            provider = next(
                (p for p in seeker.seekers if p.id == provider_id), None)
            if provider:
                logo_path = self._get_logo_path(provider)
                if logo_path and os.path.exists(logo_path):
                    request.setHeader(b"Content-Type", b"image/png")
                    with open(logo_path, "rb") as f:
                        return f.read()

            request.setResponseCode(404)
            return b"Logo not found"

        request.setResponseCode(404)
        return b"Not found"

    def render_POST(self, request):
        path = request.path.decode('utf-8', 'ignore')
        request.setHeader(b"Content-Type", b"application/json")

        try:
            body = json.loads(request.content.read().decode('utf-8'))
        except Exception:
            return json.dumps({"success": False, "message": "Invalid JSON"}).encode('utf-8')

        provider_id = body.get("provider")
        seeker = self._get_seeker_instance()
        provider = next(
            (p for p in seeker.seekers if p.id == provider_id), None)

        if not provider:
            return json.dumps({"success": False, "message": "Provider not found"}).encode('utf-8')

        if path == "/api/save":
            new_settings = body.get("settings", {})
            try:
                e2_settings = provider.settings_provider.getE2Settings()
                sorted_defaults = sorted(
                    provider.default_settings.items(), key=lambda x: x[1].get('pos', 99))

                # Match the updated field with the correct Enigma2 ConfigElement by its index position
                for i, (internal_key, dict_val) in enumerate(sorted_defaults):
                    if internal_key in new_settings and i < len(e2_settings):
                        obj = e2_settings[i][1]
                        obj.value = str(new_settings[internal_key])
                        obj.save()

                configfile.save()
                return json.dumps({"success": True}).encode('utf-8')
            except Exception as e:
                return json.dumps({"success": False, "message": str(e)}).encode('utf-8')

        elif path == "/api/test":
            if not hasattr(provider, 'test_credentials'):
                return json.dumps({"success": False, "message": "Provider does not support testing"}).encode('utf-8')

            d = provider.test_credentials()

            def onSuccess(res):
                msg = "Login successful!"
                if isinstance(res, dict) and 'user' in res:
                    msg += " VIP: " + str(res['user'].get('vip', 'No'))
                elif res:
                    msg += " " + str(res)
                request.write(json.dumps(
                    {"success": True, "message": msg}).encode('utf-8'))
                request.finish()

            def onError(err):
                request.write(json.dumps(
                    {"success": False, "message": "Error: " + str(err.value)}).encode('utf-8'))
                request.finish()

            d.addCallbacks(onSuccess, onError)
            return server.NOT_DONE_YET

        request.setResponseCode(404)
        return json.dumps({"success": False, "message": "Endpoint not found"}).encode('utf-8')


webui_site = None
webui_port_listening = None


def start_webui():
    """Initializes and starts the WebUI server on Enigma2 boot."""
    global webui_site, webui_port_listening

    if webui_port_listening:
        return  # Already running

    from .subtitles import initSubsProSettings
    settings = initSubsProSettings()
    port = int(settings.webui_port.value)

    webui_site = server.Site(SubsProWebUI())
    try:
        webui_port_listening = reactor.listenTCP(port, webui_site)
        print("[SubsSupportPro] WebUI started successfully on port {}".format(port))
    except Exception as e:
        print("[SubsSupportPro] Failed to start WebUI on port {}: {}".format(port, e))
